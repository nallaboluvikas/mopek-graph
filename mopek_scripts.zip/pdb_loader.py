"""
pdb_loader.py — loads PDB structure entries into Neo4j as :Structure nodes.

Reads data/normalized/pdb_normalized.json (already schema-mapped by
the normalization pipeline).

Maps onto:
  (:Structure {structure_id, title, experiment_type, resolution_A,
               r_free, deposition_date, release_date, organism, doi,
               structure_url, download_pdb, source: "pdb"})

NOTE (2026-08-18): NO (:Peptide)-[:HAS_STRUCTURE]->(:Structure)
relationships are created here. Confirmed by inspecting both the
normalized data (8,137 records, no chembl_id/peptide_id field in any
record) and the raw collector (pdb_collector.py): PDB entries were
found via a generic structural search — polypeptide chains of 2-50
residues (rcsb_entry_info.deposited_polymer_monomer_count range
query) — not by matching against your specific ChEMBL peptide
sequences or IDs. There is no data linking any given PDB structure
to any given peptide in this dataset as collected.

Closing this gap later would require either:
  (a) sequence-matching PDB structures against Peptide.sequence
      values already in the graph, or
  (b) re-querying PDB using your actual peptide sequences/names
      instead of the generic residue-count filter.
Both are follow-up collection/entity-resolution tasks, not done here.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class PDBLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            source_id = rec.get("source_id")
            if not source_id:
                continue  # skip records with no usable identifier

            yield {
                "structure_id": source_id,
                "title": rec.get("title"),
                "experiment_type": rec.get("experiment_type"),
                "resolution_A": rec.get("resolution_A"),
                "r_free": rec.get("r_free"),
                "deposition_date": rec.get("deposition_date"),
                "release_date": rec.get("release_date"),
                "organism": rec.get("organism"),
                "doi": rec.get("doi"),
                "structure_url": rec.get("structure_url"),
                "download_pdb": rec.get("download_pdb"),
                "confidence_tier": rec.get("confidence_tier"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (s:Structure {structure_id: row.structure_id})
              ON CREATE SET
                s.title = row.title,
                s.experiment_type = row.experiment_type,
                s.resolution_A = row.resolution_A,
                s.r_free = row.r_free,
                s.deposition_date = row.deposition_date,
                s.release_date = row.release_date,
                s.organism = row.organism,
                s.doi = row.doi,
                s.structure_url = row.structure_url,
                s.download_pdb = row.download_pdb,
                s.confidence_tier = row.confidence_tier,
                s.source = 'pdb'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to pdb_normalized.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with PDBLoader(args.uri, args.user, args.password, "pdb") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

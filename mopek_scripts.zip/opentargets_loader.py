"""
opentargets_loader.py — loads OpenTargets gene-disease association data
into Neo4j as :Disease nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/disease/opentargets.json
(2,300 records).

NOTE: this FINALLY populates the :Disease node type, which has existed
in schema.cypher since the very first schema design this project did,
but had zero records loaded into it until now — every other source
this session either had no disease data, or (PharmGKB's phenotypes)
was broader than "disease" specifically and got its own :Phenotype
type instead.

Disease.efo_id is the schema's original constraint field name, but
OpenTargets' disease_id here is actually a MONDO identifier (e.g.
"MONDO_0019115"), not EFO — stored under the efo_id property key
regardless, since that's the constraint Neo4j enforces; the property
NAME predates this data source and doesn't imply the ID format.

Maps onto:
  (:Disease {efo_id, name, source: "opentargets"})
  (:Target)-[:ASSOCIATED_WITH_DISEASE {association_score, source: "opentargets"}]->(:Disease)
    [MATCH on Target.gene_symbol]
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class OpenTargetsLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            gene = rec.get("gene")
            disease_id = rec.get("disease_id")
            if not gene or not disease_id:
                continue

            yield {
                "gene_symbol": gene,
                "efo_id": disease_id,
                "name": rec.get("disease_name"),
                "association_score": rec.get("association_score"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (d:Disease {efo_id: row.efo_id})
              ON CREATE SET
                d.name = row.name,
                d.source = 'opentargets'
            WITH d, row
            MERGE (t:Target {gene_symbol: row.gene_symbol})
              ON CREATE SET t.source = 'opentargets'
            MERGE (t)-[a:ASSOCIATED_WITH_DISEASE]->(d)
              SET a.association_score = row.association_score,
                  a.source = 'opentargets'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to disease/opentargets.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with OpenTargetsLoader(args.uri, args.user, args.password, "opentargets") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

"""
refmet_loader.py — loads RefMet reference metabolite data into Neo4j
as :Metabolite nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/refmet/refmet_all.json
(205,955 records — the full RefMet reference database from NIH
Metabolomics Workbench).

SCHEMA EXTENSION (2026-08-18): :Metabolite is not one of the original
node types in schema.cypher — added specifically for this data,
alongside the earlier :Drug extension for PharmGKB. See schema.cypher's
extension block for the constraint/index added with this loader.

Maps onto:
  (:Metabolite {refmet_id, name, pubchem_cid, inchi_key, exactmass,
                formula, super_class, main_class, sub_class,
                source: "refmet"})

No relationship to Peptide is created here — RefMet is a general
reference database (fatty acids, steroids, amino acids, etc.), not
peptide-specific, so a blanket peptide link isn't generally meaningful.
Connecting specific metabolites to specific peptides/pathways (e.g. via
shared pathway membership or a peptide's known metabolic products)
would be a follow-up entity-resolution task, not done here.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class RefMetLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            refmet_id = rec.get("refmet_id")
            if not refmet_id:
                continue  # skip records with no usable identifier

            yield {
                "refmet_id": refmet_id,
                "name": rec.get("name"),
                "pubchem_cid": rec.get("pubchem_cid"),
                "inchi_key": rec.get("inchi_key"),
                "exactmass": rec.get("exactmass"),
                "formula": rec.get("formula"),
                "super_class": rec.get("super_class"),
                "main_class": rec.get("main_class"),
                "sub_class": rec.get("sub_class"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (m:Metabolite {refmet_id: row.refmet_id})
              ON CREATE SET
                m.name = row.name,
                m.pubchem_cid = row.pubchem_cid,
                m.inchi_key = row.inchi_key,
                m.exactmass = row.exactmass,
                m.formula = row.formula,
                m.super_class = row.super_class,
                m.main_class = row.main_class,
                m.sub_class = row.sub_class,
                m.source = 'refmet'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to refmet/refmet_all.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with RefMetLoader(args.uri, args.user, args.password, "refmet") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

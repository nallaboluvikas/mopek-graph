"""
gwas_studies_loader.py — loads GWAS Catalog STUDY-level metadata into
Neo4j (distinct from gwas_bulk_loader.py, which loaded 1.15M individual
SNP-level associations; this file has 769 study-level records instead).

Reads /projects/pbpk/vikas/pepzen/data_collection/data/gwas/associations.json
(769 records).

SCHEMA EXTENSION: :GWASStudy is a new node type.

Maps onto:
  (:GWASStudy {accession_id, trait, pubmed_id, snp_count, sample_size,
               data_type, url, source: "gwas_studies"})
  (:GWASStudy)-[:STUDIES_TRAIT]->(:Phenotype)
    [MATCH on Phenotype.pharmgkb_id = "gwas:" + disease_trait — this
     reuses gwas_bulk_loader.py's synthesized Phenotype key scheme, so
     a study here will connect to the SAME Phenotype node its
     constituent SNP associations already point to, if the trait name
     matches exactly]
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class GWASStudiesLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            accession_id = rec.get("accessionId")
            if not accession_id:
                continue

            disease_trait = rec.get("disease_trait")

            yield {
                "accession_id": accession_id,
                "trait": rec.get("trait"),
                "disease_trait": disease_trait,
                "phenotype_id": f"gwas:{disease_trait}" if disease_trait else None,
                "pubmed_id": rec.get("pubmed_id"),
                "snp_count": rec.get("snp_count"),
                "sample_size": rec.get("sample_size"),
                "data_type": rec.get("data_type"),
                "url": rec.get("url"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (gs:GWASStudy {accession_id: row.accession_id})
              ON CREATE SET
                gs.trait = row.trait,
                gs.disease_trait = row.disease_trait,
                gs.pubmed_id = row.pubmed_id,
                gs.snp_count = row.snp_count,
                gs.sample_size = row.sample_size,
                gs.data_type = row.data_type,
                gs.url = row.url,
                gs.source = 'gwas_studies'
            WITH gs, row
            WHERE row.phenotype_id IS NOT NULL
            MATCH (ph:Phenotype {pharmgkb_id: row.phenotype_id})
            MERGE (gs)-[:STUDIES_TRAIT]->(ph)
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to gwas/associations.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with GWASStudiesLoader(args.uri, args.user, args.password, "gwas_studies") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

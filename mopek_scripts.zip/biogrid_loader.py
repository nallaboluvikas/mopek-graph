"""
biogrid_loader.py — loads BioGRID protein-protein interactions into
Neo4j.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/biogrid/interactions.json
(7,688 records).

Maps onto:
  (:Target)-[:INTERACTS_WITH {interaction_type, experimental_type,
                              pubmed_id, throughput, source: "biogrid"}]
           ->(:Target)

Same pattern as string_loader.py: uses MERGE on gene_symbol for both
sides, since BioGRID's own protein_a/protein_b fields are placeholder
"-" values in this dataset (not usable), while gene_a/gene_b are real
gene symbols. Creates lightweight stub Target nodes for any gene not
already in the graph, same reasoning as string_loader.py.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class BioGRIDLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            gene_a = rec.get("gene_a")
            gene_b = rec.get("gene_b")
            if not gene_a or not gene_b:
                continue

            yield {
                "gene_a": gene_a,
                "gene_b": gene_b,
                "interaction_type": rec.get("interaction_type"),
                "experimental_type": rec.get("experimental_type"),
                "pubmed_id": rec.get("pubmed_id"),
                "throughput": rec.get("throughput"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (a:Target {gene_symbol: row.gene_a})
              ON CREATE SET a.source = 'biogrid'
            MERGE (b:Target {gene_symbol: row.gene_b})
              ON CREATE SET b.source = 'biogrid'
            MERGE (a)-[r:INTERACTS_WITH {interaction_type: row.interaction_type, pubmed_id: row.pubmed_id}]->(b)
              SET r.experimental_type = row.experimental_type,
                  r.throughput = row.throughput,
                  r.source = 'biogrid'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to biogrid/interactions.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with BioGRIDLoader(args.uri, args.user, args.password, "biogrid") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

"""
intact_loader.py — loads IntAct protein-protein interactions into
Neo4j.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/intact/interactions.json
(6,714 records).

Maps onto:
  (:Target)-[:INTERACTS_WITH {interaction_type, detection_method,
                              confidence, pubmed_id, source: "intact"}]
           ->(:Target)

Same pattern as biogrid_loader.py/string_loader.py: MERGE on gene
symbol (mol_a/mol_b here), creating stub Target nodes where needed.

Note: uses the interaction's `ac` (IntAct accession) as part of the
relationship's MERGE key, same lesson learned from the ChEMBL
bioactivity fix earlier this session — without a distinguishing key,
multiple interaction records between the same gene pair (e.g. from
different assays/publications) would collapse into a single edge.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class IntActLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            mol_a = rec.get("mol_a")
            mol_b = rec.get("mol_b")
            if not mol_a or not mol_b:
                continue

            yield {
                "ac": rec.get("ac"),
                "mol_a": mol_a,
                "mol_b": mol_b,
                "interaction_type": rec.get("interaction_type"),
                "detection_method": rec.get("detection_method"),
                "confidence": rec.get("confidence"),
                "pubmed_id": rec.get("pubmed_id"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (a:Target {gene_symbol: row.mol_a})
              ON CREATE SET a.source = 'intact'
            MERGE (b:Target {gene_symbol: row.mol_b})
              ON CREATE SET b.source = 'intact'
            MERGE (a)-[r:INTERACTS_WITH {ac: row.ac}]->(b)
              SET r.interaction_type = row.interaction_type,
                  r.detection_method = row.detection_method,
                  r.confidence = row.confidence,
                  r.pubmed_id = row.pubmed_id,
                  r.source = 'intact'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to intact/interactions.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with IntActLoader(args.uri, args.user, args.password, "intact") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

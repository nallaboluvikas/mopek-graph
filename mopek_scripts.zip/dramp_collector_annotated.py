#!/usr/bin/env python3
"""
dramp_collector_annotated.py
-----------------------------
Extends dramp_collector.py to pull DRAMP's fully-annotated .txt bulk
files (not just the sequence-only .fasta files the original collector
used) — same download.php mechanism, same host, just requesting the
richer format DRAMP's own documentation confirms is available
(three formats: Fasta, xlsx, txt — see DRAMP 4.0 paper, NAR 2025).

MOTIVATION: this closes the Use Case 3 (AMP mechanism-based triage)
gap identified during use-case validation. The original dramp_loader.py
only ever had `header`, `sequence`, `dataset_category` to work with —
confirmed directly by inspecting the collected JSON — because the
.fasta bulk files DRAMP offers are sequence-only by format. DRAMP's
.txt bulk files include a `Binding_Traget` column (their own typo, kept
verbatim from source) plus Gene, Swiss_Prot_Entry, Target_Organism,
Pubmed_ID, and more — real per-peptide mechanism/target annotation
that was never collected.

Downloads the same 4 non-overlapping "by dataset" categories as the
original collector (general, patent, specific, stability), requesting
the .txt filename instead of .fasta. Tab-separated with a header row;
parsed into the same DRAMP_ID-keyed record shape.

Usage:
    python dramp_collector_annotated.py --output ./data/dramp_annotated
"""

import argparse
import csv
import io
import json
import sys
from pathlib import Path

import requests

BASE_URL = "https://dramp.cpu-bioinfor.org/downloads/download.php"

# .txt equivalents of the .fasta files the original collector used —
# same directory, same naming convention (including the source's own
# "stalitity" typo for the stability file, consistent with the
# original collector's FILES dict).
FILES = {
    "download_data/DRAMP3.0_new/general_amps.txt": "general",
    "download_data/DRAMP3.0_new/patent_amps.txt": "patent",
    "download_data/DRAMP3.0_new/specific_amps.txt": "specific",
    "download_data/DRAMP3.0_new/stability_amps.txt": "stability",  # NOTE: unlike the
    # .fasta version (which has a "stalitity" typo, per the original
    # dramp_collector.py), the .txt version uses correct spelling —
    # confirmed directly: stability_amps.txt returns HTTP 200,
    # stalitity_amps.txt returns HTTP 404.
}


def parse_annotated_txt(text):
    reader = csv.DictReader(io.StringIO(text), delimiter="\t")
    records = []
    for row in reader:
        records.append({k.strip(): (v.strip() if v else v) for k, v in row.items()})
    return records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True,
                         help="Output directory for parsed JSON files")
    args = parser.parse_args()

    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)

    all_records = []
    summary = {}

    for filename_param, category in FILES.items():
        url = f"{BASE_URL}?filename={filename_param}"
        print(f"Downloading {url} ...")
        try:
            resp = requests.get(url, timeout=60)
            resp.raise_for_status()
        except requests.exceptions.RequestException as e:
            print(f"  ERROR downloading {category}: {e}", file=sys.stderr)
            summary[category] = "FAILED (download)"
            continue

        # Sanity check: a real DRAMP txt export starts with the
        # DRAMP_ID header column, possibly quoted (e.g. general/patent/
        # specific return an unquoted "DRAMP_ID" header, but stability
        # returns a quoted '"DRAMP_ID"' header — confirmed directly by
        # inspecting a real response). Strip a leading quote before
        # checking, so both quoted and unquoted real files pass.
        first_chars = resp.text.lstrip().lstrip('"')
        if not first_chars.startswith("DRAMP_ID"):
            print(f"  WARNING: {category} response doesn't look like a "
                  f"DRAMP annotation file (first 200 chars: "
                  f"{resp.text[:200]!r}) -- skipping", file=sys.stderr)
            summary[category] = "FAILED (unexpected format)"
            continue

        records = parse_annotated_txt(resp.text)
        for r in records:
            r["dataset_category"] = category

        out_path = out_dir / f"dramp_annotated_{category}.json"
        with open(out_path, "w") as f:
            json.dump(records, f)

        print(f"  -> {len(records):,} annotated records written to {out_path}")
        summary[category] = len(records)
        all_records.extend(records)

    combined_path = out_dir / "dramp_annotated_all.json"
    with open(combined_path, "w") as f:
        json.dump(all_records, f)

    print("\n=== SUMMARY ===")
    for k, v in summary.items():
        print(f"  {k}: {v}")
    print(f"\nTotal annotated records collected: {len(all_records):,}")
    print(f"Combined file: {combined_path}")


if __name__ == "__main__":
    main()

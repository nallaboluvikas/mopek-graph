"""
pharmgkb_guideline_annotations_loader.py — loads PharmGKB/DPWG/CPIC
clinical dosing guidelines into Neo4j as :Guideline nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/pharmgkb/guideline_annotations.json
(218 records — small but deeply nested; each record has a top-level
"guideline" object plus a "citations" array).

SCHEMA EXTENSION (2026-08-19): :Guideline is not one of the original
node types — added for this data specifically.

Maps onto:
  (:Guideline {guideline_id, name, source, recommendation,
               dosing_information, has_testing_info,
               other_prescribing_guidance, pediatric, cancer_genome,
               alternate_drug_available, summary_html, text_html,
               source_name: "pharmgkb"})
  (:Guideline)-[:INVOLVES_GENE]->(:Gene)
    [MATCH on Gene.symbol from guideline.relatedGenes[].symbol]
  (:Guideline)-[:INVOLVES_DRUG]->(:Drug)
    [MATCH on Drug.pharmgkb_id from guideline.relatedChemicals[].id —
     these ARE real PharmGKB accessions, same ID scheme as
     pharmgkb_drugs_loader.py/pharmgkb_chemicals_loader.py, so this is
     a reliable match, not a fuzzy name lookup]
  (:Guideline)-[:INVOLVES_VARIANT]->(:Variant)
    [MERGE — no Variant nodes exist yet from any other loader, so
     these are created here as the first Variant nodes in the graph,
     using guideline.relatedAlleles[].id as variant_id and .symbol
     (typically an rsID) as the rsid property]
  (:Guideline)-[:CITES]->(:Publication)
    [MATCH on Publication.pmid, extracted from each citation's
     crossReferences where resource == "PubMed"; skipped if no
     matching Publication exists yet]

All relationship matches use MATCH (not MERGE) for Gene/Drug/Publication
since those should already exist from earlier loaders — unmatched
records are silently skipped by Cypher's MATCH semantics; verify
actual relationship counts via Cypher after loading, not just this
loader's row-processed count (per this session's established practice).
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


def _extract_pmids(citations: list[dict]) -> list[str]:
    pmids = []
    for cite in citations or []:
        for xref in cite.get("crossReferences") or []:
            if xref.get("resource") == "PubMed" and xref.get("resourceId"):
                pmids.append(xref["resourceId"])
    return pmids


class PharmGKBGuidelineAnnotationsLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            guideline = rec.get("guideline") or {}
            guideline_id = guideline.get("id")
            if not guideline_id:
                continue

            related_genes = [
                g.get("symbol") for g in (guideline.get("relatedGenes") or [])
                if g.get("symbol")
            ]
            related_drugs = [
                c.get("id") for c in (guideline.get("relatedChemicals") or [])
                if c.get("id")
            ]
            related_variants = [
                {"variant_id": a.get("id"), "rsid": a.get("symbol")}
                for a in (guideline.get("relatedAlleles") or [])
                if a.get("id")
            ]
            pmids = _extract_pmids(rec.get("citations") or [])

            summary_md = guideline.get("summaryMarkdown") or {}
            text_md = guideline.get("textMarkdown") or {}

            yield {
                "guideline_id": guideline_id,
                "name": guideline.get("name"),
                "source": guideline.get("source"),
                "recommendation": guideline.get("recommendation"),
                "dosing_information": guideline.get("dosingInformation"),
                "has_testing_info": guideline.get("hasTestingInfo"),
                "other_prescribing_guidance": guideline.get("otherPrescribingGuidance"),
                "pediatric": guideline.get("pediatric"),
                "cancer_genome": guideline.get("cancerGenome"),
                "alternate_drug_available": guideline.get("alternateDrugAvailable"),
                "summary_html": summary_md.get("html"),
                "text_html": text_md.get("html"),
                "related_genes": related_genes,
                "related_drugs": related_drugs,
                "related_variants": related_variants,
                "pmids": pmids,
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (gl:Guideline {guideline_id: row.guideline_id})
              ON CREATE SET
                gl.name = row.name,
                gl.source = row.source,
                gl.recommendation = row.recommendation,
                gl.dosing_information = row.dosing_information,
                gl.has_testing_info = row.has_testing_info,
                gl.other_prescribing_guidance = row.other_prescribing_guidance,
                gl.pediatric = row.pediatric,
                gl.cancer_genome = row.cancer_genome,
                gl.alternate_drug_available = row.alternate_drug_available,
                gl.summary_html = row.summary_html,
                gl.text_html = row.text_html,
                gl.source_name = 'pharmgkb'
            WITH gl, row
            UNWIND row.related_genes AS gene_symbol
            MATCH (g:Gene {symbol: gene_symbol})
            MERGE (gl)-[:INVOLVES_GENE]->(g)
            """,
            batch=batch,
        )
        tx.run(
            """
            UNWIND $batch AS row
            MATCH (gl:Guideline {guideline_id: row.guideline_id})
            UNWIND row.related_drugs AS drug_pharmgkb_id
            MATCH (d:Drug {pharmgkb_id: drug_pharmgkb_id})
            MERGE (gl)-[:INVOLVES_DRUG]->(d)
            """,
            batch=batch,
        )
        tx.run(
            """
            UNWIND $batch AS row
            MATCH (gl:Guideline {guideline_id: row.guideline_id})
            UNWIND row.related_variants AS var
            MERGE (v:Variant {variant_id: var.variant_id})
              ON CREATE SET v.rsid = var.rsid, v.source = 'pharmgkb'
            MERGE (gl)-[:INVOLVES_VARIANT]->(v)
            """,
            batch=batch,
        )
        tx.run(
            """
            UNWIND $batch AS row
            MATCH (gl:Guideline {guideline_id: row.guideline_id})
            UNWIND row.pmids AS pmid
            MATCH (pub:Publication {pmid: pmid})
            MERGE (gl)-[:CITES]->(pub)
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to pharmgkb/guideline_annotations.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with PharmGKBGuidelineAnnotationsLoader(
        args.uri, args.user, args.password, "pharmgkb_guideline_annotations"
    ) as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

"""
dramp_annotated_loader.py — loads DRAMP's fully-annotated data
(collected via dramp_collector_annotated.py) into Neo4j, closing the
Use Case 3 (AMP mechanism-based triage) gap identified during use-case
validation.

Reads data/dramp_annotated/dramp_annotated_{general,patent,specific}.json
(stability category unavailable — 404 from source, same category of
gap as PDC's OV file earlier in this project).

SCHEMA EXTENSION: :MechanismTarget is a new node type — one per
distinct real binding-target/mechanism value (e.g. "Cell membrane",
"NS3 protease", "Integrase"). This is what actually closes Use Case 3:
peptides sharing a MechanismTarget are now clusterable by real shared
mechanism, not just a flat "antimicrobial" category label.

NOTE on data quality: DRAMP's Binding_Traget field uses several
placeholder strings for missing data ("Not available", "Not found",
etc.) — confirmed directly (3,329 of 6,802 non-null-looking values in
the general dataset alone were "Not available"). These are filtered
out, same lesson as thpdb_loader.py's "N.A." brand-name placeholders.

Values are normalized (lowercased, stripped) ONLY for the grouping/
MERGE key, so "membrane", "Membrane", and "Cell membrane" are treated
as related-but-distinct mechanism categories (no fuzzy merging of
different wordings in this pass — that would be a further, riskier
resolution step). The ORIGINAL casing is kept as the node's display
name (first-seen wins).

Maps onto:
  Peptide (existing DRAMP nodes, matched on header = DRAMP_ID) enriched with:
    name, gene_raw, activity, target_organism, pubmed_ids
  (:MechanismTarget {mechanism_id, name, source: "dramp"})
  (:Peptide)-[:HAS_MECHANISM_TARGET]->(:MechanismTarget)
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader

PLACEHOLDER_VALUES = {"not available", "not found", "", "none", "n/a", "unknown", "-"}


def _is_real_value(value):
    return bool(value) and value.strip().lower() not in PLACEHOLDER_VALUES


class DRAMPAnnotatedLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            dramp_id = rec.get("DRAMP_ID")
            if not dramp_id:
                continue

            binding_target = rec.get("Binding_Traget")
            mechanism_key = binding_target.strip().lower() if _is_real_value(binding_target) else None

            pubmed_raw = rec.get("Pubmed_ID") or ""
            pubmed_ids = [p.strip() for p in pubmed_raw.split("##") if p.strip()]

            yield {
                "peptide_id": f"dramp:{dramp_id}",
                "name": rec.get("Name") if _is_real_value(rec.get("Name")) else None,
                "gene_raw": rec.get("Gene") if _is_real_value(rec.get("Gene")) else None,
                "activity": rec.get("Activity") if _is_real_value(rec.get("Activity")) else None,
                "target_organism": rec.get("Target_Organism") if _is_real_value(rec.get("Target_Organism")) else None,
                "pubmed_ids": pubmed_ids,
                "mechanism_key": mechanism_key,
                "mechanism_display_name": binding_target.strip() if mechanism_key else None,
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MATCH (p:Peptide {peptide_id: row.peptide_id})
            SET p.name = coalesce(row.name, p.name),
                p.gene_raw = row.gene_raw,
                p.activity = row.activity,
                p.target_organism = row.target_organism,
                p.pubmed_ids = row.pubmed_ids
            WITH p, row
            WHERE row.mechanism_key IS NOT NULL
            MERGE (mt:MechanismTarget {mechanism_id: row.mechanism_key})
              ON CREATE SET mt.name = row.mechanism_display_name, mt.source = 'dramp'
            MERGE (p)-[:HAS_MECHANISM_TARGET]->(mt)
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to a dramp_annotated_*.json file")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with DRAMPAnnotatedLoader(args.uri, args.user, args.password, "dramp_annotated") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

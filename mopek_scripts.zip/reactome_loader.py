"""
reactome_loader.py — loads Reactome pathway/reaction records into
Neo4j as :Pathway nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/reactome/reactions.json
(1,273 records).

NOTE: displayName often contains embedded HTML markup from the search
result highlighting (e.g. 'Peptide <span class="highlighting">hormone
</span> biosynthesis') — this loader strips HTML tags via a simple
regex before storing, so the name property is clean plain text.

Maps onto:
  (:Pathway {pathway_id, name, exact_type, species, search_term, url,
             source: "reactome"})

Reuses the :Pathway node type and pathway_id constraint already
established by pharmgkb_pathways_loader.py — Reactome's stId format
(e.g. "R-HSA-209952") is naturally distinct from PharmGKB's/KEGG's ID
schemes, so no collision risk.
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader

_TAG_RE = re.compile(r"<[^>]+>")


def _strip_html(text):
    if not text:
        return text
    return _TAG_RE.sub("", text).strip()


class ReactomeLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            st_id = rec.get("stId")
            if not st_id:
                continue

            yield {
                "pathway_id": st_id,
                "name": _strip_html(rec.get("displayName")),
                "exact_type": rec.get("exactType"),
                "species": rec.get("species"),
                "search_term": rec.get("search_term"),
                "url": rec.get("url"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (pw:Pathway {pathway_id: row.pathway_id})
              ON CREATE SET
                pw.name = row.name,
                pw.exact_type = row.exact_type,
                pw.species = row.species,
                pw.search_term = row.search_term,
                pw.url = row.url,
                pw.source = 'reactome'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to reactome/reactions.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with ReactomeLoader(args.uri, args.user, args.password, "reactome") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

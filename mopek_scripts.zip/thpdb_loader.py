"""
thpdb_loader.py — loads THPdb (Therapeutic Peptide Database) records
into Neo4j as :Peptide nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/thpdb/thpdb.json
(852 total rows, but only 239 UNIQUE th_id values — confirmed directly.
A single peptide can appear multiple times under different brand
names/manufacturers/indications, same underlying category of issue as
satpdb_loader.py's multi-category peptides, though the shape here is
different: brand-specific fields vary per row while peptide-level
fields (sequence, mechanism_of_action, target, etc.) stay constant).

thpdb_sequences.json (239 records) is NOT loaded separately — it's
redundant with thpdb.json, which already has the same sequences
keyed by the same th_id/header field.

Approach: aggregate all rows sharing a th_id in Python first. Peptide-
level fields are taken from the first row seen (they're constant
across duplicates). Brand-specific fields are collected into a
`brands` list property, one entry per distinct brand_name, so no
brand information is silently dropped the way SATPdb's categories
were before that loader was fixed.

Maps onto:
  (:Peptide {peptide_id, th_id, name, sequence, class, weight, formula,
             length, category, target, indication,
             mechanism_of_action, pharmacodynamics, description,
             brands: [{brand_name, manufacturer, brand_indication}, ...],
             pubmed_ids, source: "thpdb"})
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class THPdbLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        by_th_id: dict[str, dict] = {}
        brands_by_th_id: dict[str, list] = defaultdict(list)
        seen_brand_names: dict[str, set] = defaultdict(set)

        for rec in self.read_json(raw_path):
            th_id = rec.get("th_id")
            if not th_id:
                continue

            if th_id not in by_th_id:
                by_th_id[th_id] = rec

            brand_name = rec.get("brand_name")
            if brand_name and brand_name not in seen_brand_names[th_id]:
                seen_brand_names[th_id].add(brand_name)
                brands_by_th_id[th_id].append({
                    "brand_name": brand_name,
                    "manufacturer": rec.get("manufacturer"),
                    "brand_indication": rec.get("brand_indication"),
                })

        for th_id, rec in by_th_id.items():
            pubmed_ids_raw = rec.get("pubmed_ids") or ""
            pubmed_ids = [p.strip() for p in pubmed_ids_raw.split(",") if p.strip()]

            yield {
                "peptide_id": f"thpdb:{th_id}",
                "th_id": th_id,
                "name": rec.get("name"),
                "sequence": rec.get("sequence"),
                "peptide_class": rec.get("class"),
                "weight": rec.get("weight"),
                "formula": rec.get("formula"),
                "length": rec.get("length"),
                "category": rec.get("category"),
                "target": rec.get("target"),
                "indication": rec.get("indication"),
                "mechanism_of_action": rec.get("mechanism_of_action"),
                "pharmacodynamics": rec.get("pharmacodynamics"),
                "description": rec.get("description"),
                "brand_names": [b["brand_name"] for b in brands_by_th_id[th_id]],
                "manufacturers": [b["manufacturer"] for b in brands_by_th_id[th_id] if b["manufacturer"]],
                "pubmed_ids": pubmed_ids,
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (p:Peptide {peptide_id: row.peptide_id})
              ON CREATE SET
                p.th_id = row.th_id,
                p.name = row.name,
                p.sequence = row.sequence,
                p.peptide_class = row.peptide_class,
                p.weight = row.weight,
                p.formula = row.formula,
                p.length = row.length,
                p.category = row.category,
                p.target = row.target,
                p.indication = row.indication,
                p.mechanism_of_action = row.mechanism_of_action,
                p.pharmacodynamics = row.pharmacodynamics,
                p.description = row.description,
                p.brand_names = row.brand_names,
                p.manufacturers = row.manufacturers,
                p.pubmed_ids = row.pubmed_ids,
                p.source = 'thpdb'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to thpdb/thpdb.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with THPdbLoader(args.uri, args.user, args.password, "thpdb") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

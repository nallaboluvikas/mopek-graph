"""
pharmgkb_genes_loader.py — loads PharmGKB gene records into Neo4j as :Gene nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/pharmgkb/genes.json
(raw collector output — this is one of PharmGKB's ~10 separate datasets;
each gets its own loader given how differently structured they are).

Maps onto:
  (:Gene {ncbi_gene_id, pharmgkb_id, hgnc_id, ensembl_id, name, symbol,
          is_vip, chromosome, chr_start_grch38, chr_stop_grch38,
          source: "pharmgkb"})

Records with no NCBI Gene ID are skipped (that's the schema's uniqueness
constraint key — ncbi_gene_id — so a record without one can't be loaded
as a proper :Gene node here).

This is Step 1 of 2 for PharmGKB: clinical_variants.json and
variant_annotations.json (the PharmacogenomicAssociation data) need a
separate, more careful loader due to messier multi-value fields
(e.g. comma-separated star-alleles in one string) — not handled here.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class PharmGKBGenesLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            ncbi_gene_id = rec.get("NCBI Gene ID")
            if not ncbi_gene_id:
                continue  # skip records with no usable identifier

            yield {
                "ncbi_gene_id": ncbi_gene_id,
                "pharmgkb_id": rec.get("PharmGKB Accession Id"),
                "hgnc_id": rec.get("HGNC ID"),
                "ensembl_id": rec.get("Ensembl Id"),
                "name": rec.get("Name"),
                "symbol": rec.get("Symbol"),
                "is_vip": rec.get("Is VIP"),
                "chromosome": rec.get("Chromosome"),
                "chr_start_grch38": rec.get("Chromosomal Start - GRCh38"),
                "chr_stop_grch38": rec.get("Chromosomal Stop - GRCh38"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (g:Gene {ncbi_gene_id: row.ncbi_gene_id})
              ON CREATE SET
                g.pharmgkb_id = row.pharmgkb_id,
                g.hgnc_id = row.hgnc_id,
                g.ensembl_id = row.ensembl_id,
                g.name = row.name,
                g.symbol = row.symbol,
                g.is_vip = row.is_vip,
                g.chromosome = row.chromosome,
                g.chr_start_grch38 = row.chr_start_grch38,
                g.chr_stop_grch38 = row.chr_stop_grch38,
                g.source = 'pharmgkb'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to pharmgkb/genes.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with PharmGKBGenesLoader(args.uri, args.user, args.password, "pharmgkb_genes") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

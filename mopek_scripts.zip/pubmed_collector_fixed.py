"""
pubmed_collector_fixed.py — fixes a real, confirmed under-collection
bug in the original pubmed_collector.py.

ROOT CAUSE (confirmed 2026-09-22): PubMed's esearch backend has a
well-known real-world result cap around 9,999 records per single
query — distinct from the general E-utilities documentation, which
describes a 100,000-UID limit for esummary/efetch retrieval, not
PubMed's own search index pagination behavior. Two of the original
collector's 7 SEARCH_QUERIES silently hit this cap every run
(confirmed via multiple historical logs, all showing exactly 9999
PMIDs returned): the pharmacokinetics/ADMET query and the GLP-1/
insulin/peptide-hormone query. Verified their TRUE total match counts
directly via esearch's `count` field (which is always accurate, even
though `idlist` gets capped): 17,115 and 30,438 respectively — meaning
27,554 real articles were silently missed by those two queries alone
across every historical run. This is the root cause of the project's
documented PubMed count discrepancy (29,143 collected vs. 58,293
originally reported).

FIX: for each query, first probe the true total count (retmax=0). If
it exceeds a safe threshold (8,000, leaving headroom below the ~9,999
cap), split the query's date range (MIN_DATE-MAX_DATE) into yearly
sub-windows and search each year separately, unioning all PMIDs into
one set — the standard, reliable workaround for this PubMed-specific
limitation. If a single year's count STILL exceeds the threshold
(unlikely for these search terms, but checked), that year is further
split into half-year windows, recursively, until each sub-query is
safely under the cap.

Everything else (search query list, article metadata fetching, output
format) is unchanged from the original collector — this is a targeted
fix to the pagination/date-splitting logic only.
"""

import time
import json
import logging
import requests
import xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime
import pandas as pd

log = logging.getLogger("pepzen.pubmed")

ESEARCH_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
EFETCH_URL  = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"

NCBI_API_KEY = "c93ad63d76d7e71619559fda4f0f814ab108"

SEARCH_QUERIES = [
    '("peptide drug"[Title/Abstract] OR "therapeutic peptide"[Title/Abstract]) AND "clinical trial"[Publication Type]',
    '"antimicrobial peptide"[Title/Abstract] AND ("IC50" OR "MIC" OR "activity")',
    '"peptide"[Title/Abstract] AND ("pharmacokinetics" OR "bioavailability" OR "half-life" OR "ADMET")',
    '"anticancer peptide"[Title/Abstract] OR "antitumor peptide"[Title/Abstract]',
    '"GLP-1"[Title/Abstract] OR "insulin analogue"[Title/Abstract] OR "peptide hormone"[Title/Abstract]',
    '"cyclic peptide"[Title/Abstract] AND ("drug" OR "therapeutic" OR "activity")',
    '"stapled peptide"[Title/Abstract] OR "constrained peptide"[Title/Abstract]',
]

MIN_YEAR = 2000
MAX_YEAR = datetime.now().year
SAFE_THRESHOLD = 8000  # stay comfortably under the real ~9,999 cap


class PubMedCollector:
    def __init__(self, output_dir, max_records=None):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.max_records = max_records
        self.session = requests.Session()
        self._delay = 0.34 if not NCBI_API_KEY else 0.11

    def run(self):
        all_pmids = set()

        for query in SEARCH_QUERIES:
            log.info(f"PubMed search: {query[:70]}...")
            pmids = self._search_with_splitting(query, MIN_YEAR, MAX_YEAR)
            log.info(f"  -> {len(pmids)} PMIDs (after any date-splitting)")
            all_pmids.update(pmids)
            if self.max_records and len(all_pmids) >= self.max_records:
                break

        pmids_list = list(all_pmids)
        if self.max_records:
            pmids_list = pmids_list[: self.max_records]

        log.info(f"PubMed: fetching metadata for {len(pmids_list)} unique articles...")
        articles = self._fetch_articles(pmids_list)

        self._save("articles.json", articles)
        self._save_csv(articles)
        self._save_pmids(pmids_list)

        log.info(f"PubMed: {len(articles)} articles saved to {self.output_dir}")
        return len(articles)

    # ------------------------------------------------------------------
    # Search with automatic date-range splitting to work around the
    # ~9,999-result PubMed search cap
    # ------------------------------------------------------------------
    def _get_count(self, query, min_date, max_date):
        params = {
            "db": "pubmed", "term": query, "retmax": 0, "retmode": "json",
            "datetype": "pdat", "mindate": min_date, "maxdate": max_date,
        }
        if NCBI_API_KEY:
            params["api_key"] = NCBI_API_KEY
        data = self._get_json(ESEARCH_URL, params)
        if not data:
            return 0
        return int(data.get("esearchresult", {}).get("count", 0))

    def _search_with_splitting(self, query, start_year, end_year):
        min_date = f"{start_year}/01/01"
        max_date = f"{end_year}/12/31"
        count = self._get_count(query, min_date, max_date)
        time.sleep(self._delay)

        if count <= SAFE_THRESHOLD:
            return set(self._search(query, min_date, max_date))

        if start_year == end_year:
            log.warning(
                f"  Year {start_year} alone has {count} results (over threshold) "
                f"for this query -- splitting into half-year windows"
            )
            first_half = self._search(query, f"{start_year}/01/01", f"{start_year}/06/30")
            second_half = self._search(query, f"{start_year}/07/01", f"{start_year}/12/31")
            return set(first_half) | set(second_half)

        mid = (start_year + end_year) // 2
        log.info(f"  Query has {count} results for {start_year}-{end_year} (over threshold) -- splitting")
        left = self._search_with_splitting(query, start_year, mid)
        right = self._search_with_splitting(query, mid + 1, end_year)
        return left | right

    def _search(self, query, min_date, max_date):
        pmids = []
        retstart = 0
        retmax = 500

        while True:
            params = {
                "db": "pubmed", "term": query, "retmax": retmax, "retstart": retstart,
                "retmode": "json", "datetype": "pdat",
                "mindate": min_date, "maxdate": max_date, "usehistory": "y",
            }
            if NCBI_API_KEY:
                params["api_key"] = NCBI_API_KEY

            data = self._get_json(ESEARCH_URL, params)
            if not data:
                break

            result = data.get("esearchresult", {})
            batch_pmids = result.get("idlist", [])
            pmids.extend(batch_pmids)

            total = int(result.get("count", 0))
            retstart += retmax

            if retstart >= total or not batch_pmids:
                break
            if self.max_records and len(pmids) >= self.max_records:
                break

            time.sleep(self._delay)

        return pmids

    # ------------------------------------------------------------------
    # Unchanged from original collector below
    # ------------------------------------------------------------------
    def _get_json(self, url, params, retries=3):
        for attempt in range(retries):
            try:
                r = self.session.get(url, params=params, timeout=30)
                r.raise_for_status()
                return r.json()
            except Exception as e:
                log.warning(f"PubMed JSON request error (attempt {attempt+1}): {e}")
                time.sleep(1)
        return None

    def _fetch_articles(self, pmids):
        articles = []
        batch_size = 200
        for i in range(0, len(pmids), batch_size):
            batch = pmids[i:i + batch_size]
            params = {"db": "pubmed", "id": ",".join(batch), "rettype": "xml", "retmode": "xml"}
            if NCBI_API_KEY:
                params["api_key"] = NCBI_API_KEY
            for attempt in range(3):
                try:
                    r = self.session.get(EFETCH_URL, params=params, timeout=60)
                    r.raise_for_status()
                    articles.extend(self._parse_articles_xml(r.text))
                    break
                except Exception as e:
                    log.warning(f"PubMed XML request error (attempt {attempt+1}): {e}")
                    time.sleep(2 ** attempt)
            time.sleep(self._delay)
        return articles

    def _parse_articles_xml(self, xml_text):
        try:
            root = ET.fromstring(xml_text)
        except ET.ParseError:
            return []
        results = []
        for article in root.findall(".//PubmedArticle"):
            pmid_el = article.find(".//PMID")
            title_el = article.find(".//ArticleTitle")
            abstract_el = article.find(".//AbstractText")
            journal_el = article.find(".//Journal/Title")
            results.append({
                "pmid": pmid_el.text if pmid_el is not None else None,
                "title": title_el.text if title_el is not None else None,
                "abstract": abstract_el.text if abstract_el is not None else None,
                "journal": journal_el.text if journal_el is not None else None,
            })
        return results

    def _save(self, filename, data):
        with open(self.output_dir / filename, "w") as f:
            json.dump(data, f, indent=2)

    def _save_csv(self, articles):
        if articles:
            pd.DataFrame(articles).to_csv(self.output_dir / "articles.csv", index=False)

    def _save_pmids(self, pmids):
        with open(self.output_dir / "pmids.txt", "w") as f:
            f.write("\n".join(pmids))


if __name__ == "__main__":
    import argparse
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", required=True)
    ap.add_argument("--max-records", type=int, default=None)
    args = ap.parse_args()
    collector = PubMedCollector(Path(args.output), max_records=args.max_records)
    collector.run()

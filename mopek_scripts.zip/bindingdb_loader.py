"""
bindingdb_loader.py — loads BindingDB binding data into Neo4j.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/bindingdb/bindings.json
(raw collector output — no normalized version exists for this source).

Maps onto:
  (:Peptide {peptide_id, smiles, source: "bindingdb"})
  (:Target  {uniprot_id, gene_symbol, source: "bindingdb"})   [MERGE — may
    already exist from UniProt/STRING; ON CREATE SET only fills gene_symbol
    if the node is new, so it never overwrites richer UniProt data]
  (:Peptide)-[:BINDS {affinity_type, affinity_value, affinity_unit,
                      assay_type, pubmed_id, source: "bindingdb"}]->(:Target)

Design notes:
- No chembl_id/peptide identifier exists in this source besides its own
  bindingdb_id and a SMILES string — so per the schema's stated principle
  (one node per source record, no on-sight cross-source merging), each
  BindingDB ligand becomes its OWN :Peptide node, not matched against
  existing ChEMBL peptides by SMILES. Cross-source identity resolution
  (e.g. "is this BindingDB ligand the same molecule as ChEMBL peptide X")
  is Step 4's SAME_AS entity-resolution job, not this loader's.
- target_uniprot IS present and complete (0/70221 missing) — so BINDS
  edges connect to real :Target nodes via MERGE on uniprot_id. Where a
  uniprot_id already exists (from UniProt/STRING), this attaches to the
  same node; where it doesn't, it creates a lightweight stub (same
  pattern as string_loader.py).
- 2 of 70221 records are missing ligand_smiles; those are skipped since
  there'd be no usable peptide identity information for them at all.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class BindingDBLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            bindingdb_id = rec.get("bindingdb_id")
            uniprot_id = rec.get("target_uniprot")
            smiles = rec.get("ligand_smiles")
            if not bindingdb_id or not uniprot_id or not smiles:
                continue  # skip incomplete records

            yield {
                "peptide_id": f"bindingdb:{bindingdb_id}",
                "smiles": smiles,
                "ligand_name": rec.get("ligand_name"),
                "ligand_inchi": rec.get("ligand_inchi"),
                "uniprot_id": uniprot_id,
                "gene_symbol": rec.get("target_gene"),
                "affinity_type": rec.get("affinity_type"),
                "affinity_value": rec.get("affinity_value"),
                "affinity_unit": rec.get("affinity_unit"),
                "assay_type": rec.get("assay_type"),
                "pubmed_id": rec.get("pubmed_id") or None,
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (p:Peptide {peptide_id: row.peptide_id})
              ON CREATE SET
                p.smiles = row.smiles,
                p.name = row.ligand_name,
                p.inchi = row.ligand_inchi,
                p.source = 'bindingdb'
            MERGE (t:Target {uniprot_id: row.uniprot_id})
              ON CREATE SET
                t.gene_symbol = row.gene_symbol,
                t.source = 'bindingdb'
            MERGE (p)-[b:BINDS]->(t)
              SET b.affinity_type = row.affinity_type,
                  b.affinity_value = row.affinity_value,
                  b.affinity_unit = row.affinity_unit,
                  b.assay_type = row.assay_type,
                  b.pubmed_id = row.pubmed_id,
                  b.source = 'bindingdb'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to bindingdb/bindings.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with BindingDBLoader(args.uri, args.user, args.password, "bindingdb") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

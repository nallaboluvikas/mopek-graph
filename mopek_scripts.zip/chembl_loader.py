"""
chembl_loader.py — loads ChEMBL peptides into Neo4j.

NOTE (2026-08-18): ChEMBL bioactivity data is NOT currently loaded.
The original collection strategy (filtering molecules on
`helm_notation__isnull=false`) selects a slice of ChEMBL that has
essentially no overlap with molecules that have recorded bioactivity
data (verified: insulin human, CHEMBL1201631, a peptide with rich
assay data, has helm_notation=None and would never be selected by
this filter). Getting real peptide-target bioactivity from ChEMBL
would require a separate collection pass filtering on
`molecule_type=Protein/Peptide` instead, followed by its own
bioactivity fetch. That is a follow-up task, not done here.

This loader therefore creates ONLY:
  (:Peptide {peptide_id, chembl_id, name, sequence, smiles, ...,
             source: "chembl"})

No :Target nodes, no :BINDS relationships, from this source, for now.

Reads data/normalized/chembl_normalized.json (already schema-mapped
by the normalization pipeline), not the raw data/chembl/molecules.json.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class ChemblLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            pbid = rec.get("pbid")
            if not pbid:
                continue  # skip records with no usable identifier

            yield {
                "peptide_id": f"chembl:{pbid}",
                "chembl_id": rec.get("source_id"),
                "name": rec.get("name"),
                "sequence": rec.get("sequence"),
                "smiles": rec.get("smiles"),
                "inchi": rec.get("inchi"),
                "inchi_key": rec.get("inchi_key"),
                "molecular_weight": rec.get("molecular_weight"),
                "approval_status": rec.get("approval_status"),
                "max_phase": rec.get("max_phase"),
                "alogp": rec.get("alogp"),
                "hbd": rec.get("hbd"),
                "hba": rec.get("hba"),
                "psa": rec.get("psa"),
                "confidence_tier": rec.get("confidence_tier"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (p:Peptide {peptide_id: row.peptide_id})
              ON CREATE SET
                p.chembl_id = row.chembl_id,
                p.name = row.name,
                p.sequence = row.sequence,
                p.smiles = row.smiles,
                p.inchi = row.inchi,
                p.inchi_key = row.inchi_key,
                p.molecular_weight = row.molecular_weight,
                p.approval_status = row.approval_status,
                p.max_phase = row.max_phase,
                p.alogp = row.alogp,
                p.hbd = row.hbd,
                p.hba = row.hba,
                p.psa = row.psa,
                p.confidence_tier = row.confidence_tier,
                p.source = 'chembl'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to chembl_normalized.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with ChemblLoader(args.uri, args.user, args.password, "chembl") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

"""
cancerppd2_structures_loader.py — loads CancerPPD2 structure metadata
into Neo4j as :Structure nodes, with real HAS_STRUCTURE links to
:Peptide nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/cancerppd2_structures/structure_index.json
(5,250 records). The actual .pdb files inside all_structures.zip are
not needed for graph loading.

Maps onto:
  (:Structure {structure_id, filename, format, size_bytes, source: "cancerppd2"})
  (:Peptide {peptide_id: "cancerppd2:" + peptide_id})-[:HAS_STRUCTURE]->(:Structure)

Same success pattern as satpdb_structures_loader.py: structure_index's
peptide_id field (e.g. "1001") matches the header format used by
cancerppd2_loader.py, so a real MATCH is possible here.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class CancerPPD2StructuresLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            peptide_id = rec.get("peptide_id")
            if not peptide_id:
                continue

            yield {
                "structure_id": f"cancerppd2:{peptide_id}",
                "peptide_id": f"cancerppd2:{peptide_id}",
                "filename": rec.get("filename"),
                "format": rec.get("format"),
                "size_bytes": rec.get("size_bytes"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (s:Structure {structure_id: row.structure_id})
              ON CREATE SET
                s.filename = row.filename,
                s.format = row.format,
                s.size_bytes = row.size_bytes,
                s.source = 'cancerppd2'
            WITH s, row
            MATCH (p:Peptide {peptide_id: row.peptide_id})
            MERGE (p)-[:HAS_STRUCTURE]->(s)
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to cancerppd2_structures/structure_index.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with CancerPPD2StructuresLoader(args.uri, args.user, args.password, "cancerppd2_structures") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

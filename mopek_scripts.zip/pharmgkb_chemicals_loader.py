"""
pharmgkb_chemicals_loader.py — loads PharmGKB's full chemical
vocabulary into Neo4j, reusing the existing :Drug node type.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/pharmgkb/chemicals.json
(5,283 records).

NOTE (2026-08-19): chemicals.json is PharmGKB's COMPLETE chemical
vocabulary (Type values include Drug, Metabolite, Drug Class, Prodrug,
Biological Intermediate, Ion, Small Molecule, and combinations).
drugs.json (already loaded by pharmgkb_drugs_loader.py) turned out to
be an exact 3,756-record SUBSET of this file — confirmed by comparing
PharmGKB Accession Id sets directly (100% overlap). Loading all 5,283
records here would create ~3,756 duplicate Drug nodes.

This loader therefore only processes records whose PharmGKB Accession
Id was NOT already loaded by pharmgkb_drugs_loader.py — the remaining
~1,527 records (mostly pure "Metabolite", "Drug Class",
"Biological Intermediate", "Prodrug", "Ion" entries not classified
as "Drug" in PharmGKB's own Type field).

These are still loaded into the same :Drug node type (not :Metabolite)
even when Type says "Metabolite" — PharmGKB's own accession ID scheme
treats all of these as one shared chemical vocabulary, and the
existing :Metabolite node type is keyed on refmet_id (from a
completely different source, RefMet), which these records don't have.
Using :Drug with PharmGKB's own pharmgkb_id keeps this consistent with
pharmgkb_drugs_loader.py rather than forcing an awkward cross-source
identity match.

Maps onto:
  (:Drug {pharmgkb_id, name, generic_names, trade_names, drug_type,
          smiles, inchi, pubchem_cid, rxnorm_ids, atc_ids,
          source: "pharmgkb"})
  [MERGE on pharmgkb_id — same as pharmgkb_drugs_loader.py, so this is
   safe to run even if there were any accidental overlap]
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class PharmGKBChemicalsLoader(BaseLoader):
    def __init__(self, uri, user, password, source_name, existing_drug_ids: set[str]):
        super().__init__(uri, user, password, source_name)
        self.existing_drug_ids = existing_drug_ids
        self.skipped_already_loaded = 0

    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            pharmgkb_id = rec.get("PharmGKB Accession Id")
            if not pharmgkb_id:
                continue
            if pharmgkb_id in self.existing_drug_ids:
                self.skipped_already_loaded += 1
                continue

            yield {
                "pharmgkb_id": pharmgkb_id,
                "name": rec.get("Name"),
                "generic_names": rec.get("Generic Names"),
                "trade_names": rec.get("Trade Names"),
                "drug_type": rec.get("Type"),
                "smiles": rec.get("SMILES"),
                "inchi": rec.get("InChI"),
                "pubchem_cid": rec.get("PubChem Compound Identifiers"),
                "rxnorm_ids": rec.get("RxNorm Identifiers"),
                "atc_ids": rec.get("ATC Identifiers"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (d:Drug {pharmgkb_id: row.pharmgkb_id})
              ON CREATE SET
                d.name = row.name,
                d.generic_names = row.generic_names,
                d.trade_names = row.trade_names,
                d.drug_type = row.drug_type,
                d.smiles = row.smiles,
                d.inchi = row.inchi,
                d.pubchem_cid = row.pubchem_cid,
                d.rxnorm_ids = row.rxnorm_ids,
                d.atc_ids = row.atc_ids,
                d.source = 'pharmgkb'
            """,
            batch=batch,
        )

    def run(self, raw_path: Path) -> None:
        super().run(raw_path)
        self.log.info(
            "Skipped %d records already loaded by pharmgkb_drugs_loader.py",
            self.skipped_already_loaded,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to pharmgkb/chemicals.json")
    ap.add_argument("--drugs-json", type=Path, required=True, help="Path to pharmgkb/drugs.json, to determine overlap")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    drugs = json.loads(args.drugs_json.read_text())
    existing_ids = {r.get("PharmGKB Accession Id") for r in drugs if r.get("PharmGKB Accession Id")}

    with PharmGKBChemicalsLoader(
        args.uri, args.user, args.password, "pharmgkb_chemicals", existing_ids
    ) as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

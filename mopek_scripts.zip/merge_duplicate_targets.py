"""
merge_duplicate_targets.py — one-time cleanup script to fix duplicate
:Target nodes discovered on 2026-08-18.

ROOT CAUSE: Target.gene_symbol only had an INDEX, not a UNIQUENESS
CONSTRAINT (an index does not prevent duplicate values). Loaders that
did MERGE (t:Target {gene_symbol: ...}) inside an UNWIND batch —
string_loader.py, bindingdb_loader.py, biogrid_loader.py, intact_loader.py,
chembl_bioactivity_loader.py, chembl_merged_bioactivity_loader.py —
could silently create a NEW node instead of matching an existing one,
whenever the same gene symbol appeared more than once within a batch.
Confirmed: 2,181 distinct gene symbols had duplicates, totaling 6,874
nodes (should be ~2,181) — roughly 4,693 excess nodes.

Also folds in a real casing inconsistency found during investigation
(e.g. "INS" vs "ins" as separate values) by grouping duplicates
case-insensitively (via toUpper(gene_symbol)) and normalizing the
survivor's gene_symbol to uppercase.

No APOC available on this Neo4j instance. This script uses only plain
Cypher via the Python driver: for each duplicate group,
  1. pick a survivor (prefer one with source='uniprot', for richest
     properties; otherwise arbitrary)
  2. re-point every relationship from every other node in the group
     onto the survivor, one relationship TYPE at a time (Cypher
     requires a static relationship type in CREATE, so each type
     used by :Target — currently BINDS and INTERACTS_WITH — is
     handled by its own explicit Cypher block, not a dynamic loop)
  3. delete the now-relationship-free duplicate nodes

This is a ONE-TIME fix, not a reusable loader — run once, verify with
the follow-up count queries in the project notes, then move on. The
real long-term fix (a genuine UNIQUENESS CONSTRAINT on gene_symbol)
must be added AFTER this script finishes — Neo4j refuses to create a
constraint while duplicate values exist.
"""

from __future__ import annotations

import argparse
import logging

from neo4j import GraphDatabase

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
log = logging.getLogger("merge_duplicate_targets")

# Relationship types known to touch :Target as of 2026-08-18.
# If a new loader adds a relationship type touching Target later,
# add a corresponding block below before rerunning this script.
INCOMING_REL_TYPES = ["BINDS"]  # (:Peptide)-[:BINDS]->(:Target)
TARGET_TARGET_REL_TYPES = ["INTERACTS_WITH"]  # (:Target)-[:INTERACTS_WITH]->(:Target)


def get_duplicate_groups(session) -> list[tuple[str, list[str]]]:
    result = session.run(
        """
        MATCH (t:Target)
        WHERE t.gene_symbol IS NOT NULL
        WITH toUpper(t.gene_symbol) AS symbol, collect(elementId(t)) AS node_ids
        WHERE size(node_ids) > 1
        RETURN symbol, node_ids
        """
    )
    return [(rec["symbol"], rec["node_ids"]) for rec in result]


def pick_survivor(session, node_ids: list[str]) -> str:
    rec = session.run(
        """
        UNWIND $ids AS id
        MATCH (t:Target) WHERE elementId(t) = id
        RETURN elementId(t) AS id
        ORDER BY CASE WHEN t.source = 'uniprot' THEN 0 ELSE 1 END
        LIMIT 1
        """,
        ids=node_ids,
    ).single()
    return rec["id"]


def reattach_and_merge_group(session, symbol: str, node_ids: list[str]) -> None:
    survivor_id = pick_survivor(session, node_ids)
    duplicate_ids = [nid for nid in node_ids if nid != survivor_id]
    if not duplicate_ids:
        return

    # Re-point incoming relationships (e.g. Peptide-[:BINDS]->duplicate)
    for rel_type in INCOMING_REL_TYPES:
        session.run(
            f"""
            MATCH (survivor:Target) WHERE elementId(survivor) = $survivor_id
            UNWIND $dup_ids AS dup_id
            MATCH (dup:Target) WHERE elementId(dup) = dup_id
            MATCH (src)-[r:{rel_type}]->(dup)
            WITH survivor, src, r, properties(r) AS props
            CREATE (src)-[newr:{rel_type}]->(survivor)
            SET newr = props
            WITH r
            DELETE r
            """,
            survivor_id=survivor_id,
            dup_ids=duplicate_ids,
        )

    # Re-point Target-Target relationships in both directions
    for rel_type in TARGET_TARGET_REL_TYPES:
        # duplicate -> other (other is not itself a duplicate in this group)
        session.run(
            f"""
            MATCH (survivor:Target) WHERE elementId(survivor) = $survivor_id
            UNWIND $dup_ids AS dup_id
            MATCH (dup:Target) WHERE elementId(dup) = dup_id
            MATCH (dup)-[r:{rel_type}]->(other)
            WHERE NOT elementId(other) IN $dup_ids AND elementId(other) <> $survivor_id
            WITH survivor, other, r, properties(r) AS props
            CREATE (survivor)-[newr:{rel_type}]->(other)
            SET newr = props
            WITH r
            DELETE r
            """,
            survivor_id=survivor_id,
            dup_ids=duplicate_ids,
        )
        # other -> duplicate
        session.run(
            f"""
            MATCH (survivor:Target) WHERE elementId(survivor) = $survivor_id
            UNWIND $dup_ids AS dup_id
            MATCH (dup:Target) WHERE elementId(dup) = dup_id
            MATCH (other)-[r:{rel_type}]->(dup)
            WHERE NOT elementId(other) IN $dup_ids AND elementId(other) <> $survivor_id
            WITH survivor, other, r, properties(r) AS props
            CREATE (other)-[newr:{rel_type}]->(survivor)
            SET newr = props
            WITH r
            DELETE r
            """,
            survivor_id=survivor_id,
            dup_ids=duplicate_ids,
        )
        # duplicate <-> duplicate within the same group — collapse onto a
        # survivor self-loop (MERGE, so multiple such pairs don't pile up)
        session.run(
            f"""
            MATCH (survivor:Target) WHERE elementId(survivor) = $survivor_id
            UNWIND $dup_ids AS dup_id
            MATCH (dup:Target) WHERE elementId(dup) = dup_id
            MATCH (dup)-[r:{rel_type}]->(dup2:Target)
            WHERE elementId(dup2) IN $dup_ids
            WITH survivor, r, properties(r) AS props
            MERGE (survivor)-[newr:{rel_type}]->(survivor)
            SET newr = props
            WITH r
            DELETE r
            """,
            survivor_id=survivor_id,
            dup_ids=duplicate_ids,
        )

    # Normalize survivor's gene_symbol casing, then delete now-isolated duplicates
    session.run(
        """
        MATCH (survivor:Target) WHERE elementId(survivor) = $survivor_id
        SET survivor.gene_symbol = $symbol
        WITH survivor
        UNWIND $dup_ids AS dup_id
        MATCH (dup:Target) WHERE elementId(dup) = dup_id
        DETACH DELETE dup
        """,
        survivor_id=survivor_id,
        symbol=symbol,
        dup_ids=duplicate_ids,
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    ap.add_argument("--dry-run", action="store_true", help="Report only, do not modify data")
    args = ap.parse_args()

    driver = GraphDatabase.driver(args.uri, auth=(args.user, args.password))
    try:
        with driver.session() as session:
            groups = get_duplicate_groups(session)
            log.info("Found %d duplicate gene_symbol groups", len(groups))

            if args.dry_run:
                for symbol, node_ids in sorted(groups, key=lambda g: -len(g[1]))[:20]:
                    log.info("  %s: %d nodes", symbol, len(node_ids))
                log.info("Dry run — no changes made.")
                return

            for i, (symbol, node_ids) in enumerate(groups):
                reattach_and_merge_group(session, symbol, node_ids)
                if (i + 1) % 100 == 0:
                    log.info("Merged %d/%d groups", i + 1, len(groups))

            log.info("Done. Merged %d duplicate groups.", len(groups))
    finally:
        driver.close()


if __name__ == "__main__":
    main()

"""
dbaasp_loader.py — loads DBAASP peptide data (from dbaasp_collector.py)
into Neo4j.

--mode list handles Phase 1 data (data/dbaasp/dbaasp_list.json,
25,542 records): basic peptide records — name, sequence, complexity,
pdb, and for multimer/multi_peptide entries, a `monomers` array of
sub-chains each with their own sequence.

For monomer/multimer handling: a "monomer" complexity peptide has its
real sequence directly in the `sequence` field. A "multimer"/
"multi_peptide" entry's own `sequence` field is empty (confirmed
directly: e.g. "Distinctin", id=1, complexity=multimer, top-level
sequence="") — the real per-chain sequences live in its `monomers`
array instead. This loader stores the top-level record as one Peptide
node regardless, with monomer chain data captured as a list of
JSON-serialized strings (Neo4j cannot store a list of maps directly,
per this project's established pattern) rather than losing that data
or fabricating a combined sequence that wouldn't be biologically real.

Maps onto:
  (:Peptide {peptide_id, dbaasp_id, name, sequence, sequence_length,
             complexity, pdb, monomer_chains: [json_string, ...],
             source: "dbaasp"})
"""

from __future__ import annotations

import argparse
import json as json_module
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class DBAASPListLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            peptide_id = rec.get("id")
            if peptide_id is None:
                continue

            monomers = rec.get("monomers") or []
            monomer_chains = [
                json_module.dumps({
                    "name": m.get("name"),
                    "sequence": m.get("sequence"),
                    "sequence_length": m.get("sequenceLength"),
                })
                for m in monomers
            ]

            yield {
                "peptide_id": f"dbaasp:{peptide_id}",
                "dbaasp_id": rec.get("dbaaspId"),
                "name": rec.get("name"),
                "sequence": rec.get("sequence") or None,
                "sequence_length": rec.get("sequenceLength"),
                "complexity": rec.get("complexity"),
                "pdb": rec.get("pdb") or None,
                "monomer_chains": monomer_chains,
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (p:Peptide {peptide_id: row.peptide_id})
              ON CREATE SET
                p.dbaasp_id = row.dbaasp_id,
                p.name = row.name,
                p.sequence = row.sequence,
                p.sequence_length = row.sequence_length,
                p.complexity = row.complexity,
                p.pdb = row.pdb,
                p.monomer_chains = row.monomer_chains,
                p.source = 'dbaasp'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to dbaasp/dbaasp_list.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with DBAASPListLoader(args.uri, args.user, args.password, "dbaasp") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

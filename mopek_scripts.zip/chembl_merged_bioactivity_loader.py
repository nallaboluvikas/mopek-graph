"""
chembl_merged_bioactivity_loader.py — loads the broader ChEMBL bulk
bioactivity dataset into Neo4j.

Reads:
  /projects/pbpk/vikas/pepzen/data_collection/data/chembl_bulk/chembl_bioactivity_merged.json
    (69,728 records — de-duped, merged ChEMBL bulk bioactivity data;
    a broader molecule set than the ~22,050 peptides already loaded
    from chembl_normalized.json)
  /projects/pbpk/vikas/pepzen/data_collection/data/chembl_bulk/chembl_uniprot_mapping.json
    (17,257 records — same mapping file used by chembl_bioactivity_loader.py;
    see that file's docstring for the field-name-swap note)

Unlike chembl_bioactivity_loader.py (which only MATCHed existing
Peptide nodes by chembl_id), this loader uses MERGE on chembl_id for
the Peptide side too — since this dataset's molecule set is broader
than what's already in the graph, many molecule_chembl_id values here
won't already exist as Peptide nodes. New ones get created with
minimal properties (chembl_id, source); existing ones (matched by
chembl_id) are left with their richer chembl_normalized.json data
intact, since ON CREATE SET only fires for genuinely new nodes.

Maps onto:
  (:Peptide {chembl_id, source: "chembl_bulk"})  [only set on new nodes]
  (:Target  {uniprot_id, gene_symbol, source: "chembl_bulk"})
  (:Peptide)-[:BINDS {activity_id, standard_type, standard_value,
                      standard_units, standard_relation, pchembl_value,
                      assay_type, confidence_score, source: "chembl_bulk"}]
           ->(:Target)

NOTE (2026-08-18, post-load fix): activity_id is included in the
relationship's MERGE key, same reasoning as chembl_bioactivity_loader.py
— without it, multiple distinct assays for the same peptide-target pair
collapse into one relationship. The first run of this loader (before
this fix) produced 42,561 processed records but only 25,251 actual
relationships in Neo4j — confirmed by direct Cypher count, not just the
loader's log. Those collapsed relationships should be deleted before
rerunning this fixed version (see project notes).

Records whose target_chembl_id has no entry in the mapping file are
skipped (same limitation as chembl_bioactivity_loader.py — the mapping
covers only 17,257 targets, not necessarily all ChEMBL targets
referenced here).
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class ChemblMergedBioactivityLoader(BaseLoader):
    def __init__(self, uri, user, password, source_name, mapping_path: Path):
        super().__init__(uri, user, password, source_name)
        self.target_map = self._load_mapping(mapping_path)
        self.skipped_no_mapping = 0

    @staticmethod
    def _load_mapping(mapping_path: Path) -> dict:
        raw = json.loads(mapping_path.read_text())
        # NOTE: fields are swapped in the source file — see
        # chembl_bioactivity_loader.py's docstring for details.
        mapping = {}
        for rec in raw:
            chembl_target_id = rec.get("uniprot_id")  # actually a CHEMBL ID
            uniprot_accession = rec.get("chembl_id")   # actually a UniProt accession
            if chembl_target_id and uniprot_accession:
                mapping[chembl_target_id] = uniprot_accession
        return mapping

    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            chembl_id = rec.get("molecule_chembl_id")
            target_chembl_id = rec.get("target_chembl_id")
            if not chembl_id or not target_chembl_id:
                continue

            uniprot_id = self.target_map.get(target_chembl_id)
            if not uniprot_id:
                self.skipped_no_mapping += 1
                continue

            yield {
                "activity_id": rec.get("activity_id"),
                "chembl_id": chembl_id,
                "uniprot_id": uniprot_id,
                "target_name": rec.get("target_name"),
                "standard_type": rec.get("standard_type"),
                "standard_value": rec.get("standard_value"),
                "standard_units": rec.get("standard_units"),
                "standard_relation": rec.get("standard_relation"),
                "pchembl_value": rec.get("pchembl_value"),
                "assay_type": rec.get("assay_type"),
                "confidence_score": rec.get("confidence_score"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (p:Peptide {chembl_id: row.chembl_id})
              ON CREATE SET p.source = 'chembl_bulk'
            MERGE (t:Target {uniprot_id: row.uniprot_id})
              ON CREATE SET t.gene_symbol = row.target_name, t.source = 'chembl_bulk'
            MERGE (p)-[b:BINDS {activity_id: row.activity_id}]->(t)
              SET b.target_name = row.target_name,
                  b.standard_type = row.standard_type,
                  b.standard_value = row.standard_value,
                  b.standard_units = row.standard_units,
                  b.standard_relation = row.standard_relation,
                  b.pchembl_value = row.pchembl_value,
                  b.assay_type = row.assay_type,
                  b.confidence_score = row.confidence_score,
                  b.source = 'chembl_bulk'
            """,
            batch=batch,
        )

    def run(self, raw_path: Path) -> None:
        super().run(raw_path)
        self.log.info(
            "Skipped %d records with no ChEMBL target -> UniProt mapping",
            self.skipped_no_mapping,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to chembl_bulk/chembl_bioactivity_merged.json")
    ap.add_argument("--mapping", type=Path, required=True, help="Path to chembl_uniprot_mapping.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with ChemblMergedBioactivityLoader(
        args.uri, args.user, args.password, "chembl_merged_bioactivity", args.mapping
    ) as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

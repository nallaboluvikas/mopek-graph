"""
pharmgkb_clinical_variants_loader.py — loads PharmGKB clinical variant
annotations into Neo4j as :PharmacogenomicAssociation nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/pharmgkb/clinical_variants.json
(2 of PharmGKB's ~10 datasets; genes.json was Step 1, this is Step 2).

Maps onto:
  (:PharmacogenomicAssociation {pgx_id, variant, assoc_type,
                                level_of_evidence, chemicals, phenotypes,
                                source: "pharmgkb"})
  (:PharmacogenomicAssociation)-[:ASSOCIATED_WITH_GENE]->(:Gene)
    [MATCH on Gene.symbol — only connects where the gene already exists
     from the genes.json load; does not create Gene stubs, since a
     missing gene here more likely means a symbol mismatch than a
     genuinely new gene]

NOTE (2026-08-18): NO (:Peptide)-[:HAS_PHARMACOGENOMIC_ASSOCIATION]->(:Gene)
relationship is created, even though that's the relationship the schema
documents. This PharmGKB dataset is gene-drug-phenotype data (e.g. "does
variant X in gene Y change how a patient responds to drug Z") with no
peptide identifier anywhere in the source — same category of gap as
ChEMBL bioactivity, PDB structure linkage, and PubMed citation linkage.
Closing it would require matching PharmGKB's `chemicals` field against
peptide names in the graph, which is a separate entity-resolution task.

Each source row becomes ONE PharmacogenomicAssociation node — the
"variant" field often contains multiple comma-separated star-alleles
(e.g. "CYP2C9*1, CYP2C9*3, CYP2C9*13") describing one clinical
association as a set; these are kept together as originally recorded
rather than split into separate per-allele nodes, since PharmGKB itself
groups them as one annotation.

pgx_id is synthesized (pharmgkb:cv:<row index>) since this dataset has
no native per-row identifier of its own — only genes.json and
variant_annotations.json have real IDs (PharmGKB Accession Id /
Variant Annotation ID respectively).
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class PharmGKBClinicalVariantsLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for i, rec in enumerate(self.read_json(raw_path)):
            gene_symbol = rec.get("gene")
            if not gene_symbol:
                continue  # skip records with no gene to anchor on

            yield {
                "pgx_id": f"pharmgkb:cv:{i}",
                "gene_symbol": gene_symbol,
                "variant": rec.get("variant"),
                "assoc_type": rec.get("type"),
                "level_of_evidence": rec.get("level of evidence"),
                "chemicals": rec.get("chemicals"),
                "phenotypes": rec.get("phenotypes"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (pg:PharmacogenomicAssociation {pgx_id: row.pgx_id})
              ON CREATE SET
                pg.variant = row.variant,
                pg.assoc_type = row.assoc_type,
                pg.level_of_evidence = row.level_of_evidence,
                pg.chemicals = row.chemicals,
                pg.phenotypes = row.phenotypes,
                pg.source = 'pharmgkb'
            WITH pg, row
            MATCH (g:Gene {symbol: row.gene_symbol})
            MERGE (pg)-[:ASSOCIATED_WITH_GENE]->(g)
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to pharmgkb/clinical_variants.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with PharmGKBClinicalVariantsLoader(
        args.uri, args.user, args.password, "pharmgkb_clinical_variants"
    ) as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

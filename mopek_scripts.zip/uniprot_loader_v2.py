"""
uniprot_loader_v2.py — loads the REAL UniProt dataset (21,811 entries)
from /projects/pbpk/vikas/pepzen/data_collection/data/uniprot/entries.json
into Neo4j as :Target nodes.

NOTE (2026-08-18): supersedes the earlier uniprot_loader.py, which read
a smaller, stale copy from /home/nallabolu.v/pepzen/data_collection/
(1,080 records — an early/partial run, not the full collection). All
future loading should read exclusively from /projects/pbpk/vikas/...,
per the project's own Notion documentation.

Field names differ from the /home/ version's normalized file:
  accession (not source_id), protein_name (not name), mass (not
  molecular_weight) — this raw file was never run through the
  normalization pipeline, unlike the /home/ copy.

Uses plain SET (not ON CREATE SET) so that any stale Target node
already in the graph from the earlier /home/-sourced load gets
overwritten with the correct, complete data here — the /projects/
data is authoritative per the project's own record-keeping.

Maps onto:
  (:Target {uniprot_id, gene_symbol, gene_synonyms, name, entry_name,
            sequence, length, mass, organism, reviewed,
            annotation_score, pdb_ids, chembl_ids, drugbank_ids,
            source: "uniprot"})

pdb_ids/chembl_ids/drugbank_ids are captured as list properties here
(previously not loaded at all) — these are cross-reference IDs that
could help close some of the linkage gaps flagged in earlier loaders
(e.g. matching a Target's chembl_ids against existing :Peptide nodes),
but that matching is a follow-up task, not done in this loader.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


def _clean_list(values) -> list:
    return [v for v in (values or []) if v is not None]


class UniProtLoaderV2(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            uniprot_id = rec.get("accession")
            if not uniprot_id:
                continue  # skip records with no usable identifier

            gene_names = _clean_list(rec.get("gene_names"))

            yield {
                "uniprot_id": uniprot_id,
                "gene_symbol": gene_names[0] if gene_names else None,
                "gene_synonyms": gene_names,
                "name": rec.get("protein_name"),
                "entry_name": rec.get("entry_name"),
                "sequence": rec.get("sequence"),
                "length": rec.get("length"),
                "mass": rec.get("mass"),
                "organism": rec.get("organism"),
                "reviewed": rec.get("reviewed"),
                "annotation_score": rec.get("annotation_score"),
                "pdb_ids": _clean_list(rec.get("pdb_ids")),
                "chembl_ids": _clean_list(rec.get("chembl_ids")),
                "drugbank_ids": _clean_list(rec.get("drugbank_ids")),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (t:Target {uniprot_id: row.uniprot_id})
              SET
                t.gene_symbol = row.gene_symbol,
                t.gene_synonyms = row.gene_synonyms,
                t.name = row.name,
                t.entry_name = row.entry_name,
                t.sequence = row.sequence,
                t.length = row.length,
                t.mass = row.mass,
                t.organism = row.organism,
                t.reviewed = row.reviewed,
                t.annotation_score = row.annotation_score,
                t.pdb_ids = row.pdb_ids,
                t.chembl_ids = row.chembl_ids,
                t.drugbank_ids = row.drugbank_ids,
                t.source = 'uniprot'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to uniprot/entries.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with UniProtLoaderV2(args.uri, args.user, args.password, "uniprot_v2") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

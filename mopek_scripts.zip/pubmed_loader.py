"""
pubmed_loader.py — loads PubMed articles into Neo4j as :Publication nodes.

UPDATE (2026-09-22): now handles two possible input shapes safely:
  (a) the original, richer schema (pmid, title, abstract, authors,
      journal, pub_date, doi, mesh_terms, chemicals, keywords,
      pubmed_url) from the initial 29,143-record collection
  (b) the reduced schema (pmid, title, abstract, journal only) from
      pubmed_collector_fixed.py's 51,159-record RE-collection, which
      fixed a confirmed PubMed esearch ~9,999-result cap that silently
      under-collected two of the seven search queries in the original
      run (verified via esearch's `count` field: those two queries'
      TRUE totals were 17,115 and 30,438, not the 9,999 each that was
      actually returned every historical run — this fully explains the
      project's long-standing PubMed count discrepancy).

Missing fields in shape (b) are simply left as None/empty — not a
data-quality issue, just a smaller field set for records collected via
the fix. Re-running this loader with either file is safe: MERGE on
pmid means records already loaded keep their richer original fields
(ON CREATE SET only fires for genuinely new nodes), and new records
(the ~22K gained from the cap fix) get whatever fields are available.

Usage: pass either data/pubmed/articles.json (original) or
data/pubmed_fixed/articles.json (re-collected) as the raw_path argument.
Run BOTH in sequence to get the full, correct 51,159-ish total.
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


def _extract_year(pub_date):
    if not pub_date:
        return None
    match = re.search(r"\b(19|20)\d{2}\b", pub_date)
    return int(match.group()) if match else None


class PubMedLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            pmid = rec.get("pmid")
            if not pmid:
                continue

            yield {
                "pmid": pmid,
                "title": rec.get("title"),
                "abstract": rec.get("abstract"),
                "journal": rec.get("journal"),
                "pub_date": rec.get("pub_date"),
                "year": _extract_year(rec.get("pub_date")),
                "doi": rec.get("doi"),
                "authors": [a for a in (rec.get("authors") or []) if a is not None],
                "mesh_terms": [m for m in (rec.get("mesh_terms") or []) if m is not None],
                "chemicals": [c for c in (rec.get("chemicals") or []) if c is not None],
                "keywords": [k for k in (rec.get("keywords") or []) if k is not None],
                "pubmed_url": rec.get("pubmed_url") or f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/",
                "confidence_tier": rec.get("confidence_tier"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (pub:Publication {pmid: row.pmid})
              ON CREATE SET
                pub.title = row.title,
                pub.abstract = row.abstract,
                pub.journal = row.journal,
                pub.pub_date = row.pub_date,
                pub.year = row.year,
                pub.doi = row.doi,
                pub.authors = row.authors,
                pub.mesh_terms = row.mesh_terms,
                pub.chemicals = row.chemicals,
                pub.keywords = row.keywords,
                pub.pubmed_url = row.pubmed_url,
                pub.confidence_tier = row.confidence_tier,
                pub.source = 'pubmed'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to a pubmed articles.json file")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with PubMedLoader(args.uri, args.user, args.password, "pubmed") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

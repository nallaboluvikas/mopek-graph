"""
dramp_loader.py — loads DRAMP antimicrobial peptide sequences into
Neo4j as :Peptide nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/dramp/dramp_all.json
(36,723 records — confirmed to be the exact merge of the 3 category
files: dramp_general.json (11,687) + dramp_patent.json (18,715) +
dramp_specific.json (6,321) = 36,723. Only this merged file is loaded.
dramp_stability.json is empty (2 bytes) and ignored.

Unlike SATPdb, DRAMP headers are unique across the whole merged file
(36,723 records, 36,723 unique headers, verified directly) — each
peptide belongs to exactly one dataset_category, so no multi-category
list aggregation is needed here (contrast with satpdb_loader.py, which
required that fix after finding 8,103 peptides in multiple categories).

Maps onto:
  (:Peptide {peptide_id, header, sequence, dataset_category, source: "dramp"})
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class DRAMPLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            header = rec.get("header")
            if not header:
                continue  # skip records with no usable identifier

            yield {
                "peptide_id": f"dramp:{header}",
                "header": header,
                "sequence": rec.get("sequence"),
                "dataset_category": rec.get("dataset_category"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (p:Peptide {peptide_id: row.peptide_id})
              ON CREATE SET
                p.header = row.header,
                p.sequence = row.sequence,
                p.dataset_category = row.dataset_category,
                p.source = 'dramp'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to dramp/dramp_all.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with DRAMPLoader(args.uri, args.user, args.password, "dramp") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

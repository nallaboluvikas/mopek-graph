"""
uniprot_loader.py — loads UniProt proteins into Neo4j as :Target nodes.

Reads data/normalized/uniprot_normalized.json (already schema-mapped
by the normalization pipeline).

Maps onto:
  (:Target {uniprot_id, gene_symbol, name, sequence, organism,
            length, molecular_weight, reviewed, source: "uniprot"})

Note: gene_names in the source data is a list (a UniProt entry can
have synonyms); we take the first entry as the primary gene_symbol
and keep the full list as gene_synonyms for reference.

No relationships are created here — this just seeds :Target nodes.
Other loaders (STRING for INTERACTS_WITH, ChEMBL/others for BINDS,
etc.) will MERGE onto these same nodes by uniprot_id later.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class UniProtLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            uniprot_id = rec.get("source_id")
            if not uniprot_id:
                continue  # skip records with no usable identifier

            gene_names = [g for g in (rec.get("gene_names") or []) if g is not None]

            yield {
                "uniprot_id": uniprot_id,
                "gene_symbol": gene_names[0] if gene_names else None,
                "gene_synonyms": gene_names,
                "name": rec.get("name"),
                "entry_name": rec.get("entry_name"),
                "sequence": rec.get("sequence"),
                "length": rec.get("length"),
                "molecular_weight": rec.get("molecular_weight"),
                "organism": rec.get("organism"),
                "reviewed": rec.get("reviewed"),
                "annotation_score": rec.get("annotation_score"),
                "confidence_tier": rec.get("confidence_tier"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (t:Target {uniprot_id: row.uniprot_id})
              ON CREATE SET
                t.gene_symbol = row.gene_symbol,
                t.gene_synonyms = row.gene_synonyms,
                t.name = row.name,
                t.entry_name = row.entry_name,
                t.sequence = row.sequence,
                t.length = row.length,
                t.molecular_weight = row.molecular_weight,
                t.organism = row.organism,
                t.reviewed = row.reviewed,
                t.annotation_score = row.annotation_score,
                t.confidence_tier = row.confidence_tier,
                t.source = 'uniprot'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to uniprot_normalized.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with UniProtLoader(args.uri, args.user, args.password, "uniprot") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

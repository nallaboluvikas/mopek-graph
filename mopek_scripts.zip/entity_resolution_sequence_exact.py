"""
entity_resolution_sequence_exact.py — Step 4 of the project's rollout
plan: entity resolution via SAME_AS relationships.

This is the FIRST resolution pass — the highest-confidence, lowest-
false-positive-risk method available: EXACT SEQUENCE MATCH across
different Peptide sources. If two Peptide nodes from different
sources (e.g. ChEMBL and SATPdb) have byte-for-byte identical
sequences, that is about as close to certain identity as entity
resolution gets for peptides — a real amino acid sequence is
essentially a unique string.

Deliberately conservative for this first pass:
  - Only matches peptides with a non-empty `sequence` property (some
    sources, e.g. BindingDB, key on SMILES instead — those are left
    for a future SMILES-based or InChIKey-based resolution pass, not
    attempted here).
  - Only creates SAME_AS between nodes from DIFFERENT `source` values
    — same-source duplicates should already be deduplicated via each
    source's own peptide_id constraint, so a same-source match here
    would indicate a loader bug, not a real resolution case, and is
    skipped rather than silently linked.
  - Sequence is normalized (stripped, uppercased) only for the
    GROUPING key — the original `sequence` property on each node is
    never modified.

Does NOT modify or merge the underlying Peptide nodes themselves —
per the schema's original design (documented in schema.cypher since
the first schema pass): each source keeps its own node, SAME_AS is a
separate relationship carrying a confidence score and method, so full
provenance of which source contributed which node is preserved.

Maps onto:
  (:Peptide)-[:SAME_AS {confidence: 1.0, method: "sequence_exact"}]->(:Peptide)

Given the graph's scale (158,043 Peptide nodes), grouping is done in
Python (not a Cypher cartesian join across all pairs, which risks
blowing up), fetching only sequence/source/peptide_id fields — a
small, bounded in-memory operation even at this node count.
"""

from __future__ import annotations

import argparse
import logging
from collections import defaultdict

from neo4j import GraphDatabase

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
log = logging.getLogger("entity_resolution_sequence_exact")

BATCH_SIZE = 2000


def fetch_all_peptides(session):
    result = session.run(
        """
        MATCH (p:Peptide)
        WHERE p.sequence IS NOT NULL AND p.sequence <> ''
        RETURN p.peptide_id AS peptide_id, p.sequence AS sequence, p.source AS source
        """
    )
    return [(rec["peptide_id"], rec["sequence"], rec["source"]) for rec in result]


def build_same_as_pairs(peptides):
    groups = defaultdict(list)
    for peptide_id, sequence, source in peptides:
        key = sequence.strip().upper()
        groups[key].append((peptide_id, source))

    pairs = []
    for members in groups.values():
        if len(members) < 2:
            continue
        # only pair members from DIFFERENT sources
        for i in range(len(members)):
            for j in range(i + 1, len(members)):
                id_a, source_a = members[i]
                id_b, source_b = members[j]
                if source_a != source_b:
                    pairs.append((id_a, id_b))
    return pairs


def write_same_as_batch(session, batch):
    session.run(
        """
        UNWIND $batch AS pair
        MATCH (a:Peptide {peptide_id: pair[0]})
        MATCH (b:Peptide {peptide_id: pair[1]})
        MERGE (a)-[r:SAME_AS]->(b)
          SET r.confidence = 1.0,
              r.method = 'sequence_exact'
        """,
        batch=[[a, b] for a, b in batch],
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    driver = GraphDatabase.driver(args.uri, auth=(args.user, args.password))
    try:
        with driver.session() as session:
            log.info("Fetching all Peptide nodes with a non-empty sequence...")
            peptides = fetch_all_peptides(session)
            log.info("Fetched %d peptides", len(peptides))

            pairs = build_same_as_pairs(peptides)
            log.info("Found %d cross-source exact-sequence-match pairs", len(pairs))

            if args.dry_run:
                for p in pairs[:20]:
                    log.info("  %s", p)
                log.info("Dry run — no relationships created.")
                return

            for i in range(0, len(pairs), BATCH_SIZE):
                batch = pairs[i : i + BATCH_SIZE]
                write_same_as_batch(session, batch)
                log.info("Wrote %d/%d SAME_AS relationships", min(i + BATCH_SIZE, len(pairs)), len(pairs))

            log.info("Done. %d SAME_AS relationships created/verified.", len(pairs))
    finally:
        driver.close()


if __name__ == "__main__":
    main()

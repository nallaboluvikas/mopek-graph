"""
satpdb_loader.py — loads SATPdb peptide sequences into Neo4j as
:Peptide nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/satpdb/satpdb_all.json
(28,373 records — confirmed to be the exact merge of all 10 individual
category files: antibacterial, anticancer, antifungal, antihypertensive,
antimicrobial, antiparasitic, antiviral, cell_cell_communication,
drug_delivery_vehicle, toxic. Only this merged file is loaded — NOT
the 10 category files individually, which would double-count every
record.)

NOTE (2026-08-18, post-load fix): satpdb_all.json has 28,373 total
records but only 17,355 UNIQUE headers — many peptides genuinely
belong to multiple therapeutic categories (e.g. both "antibacterial"
and "toxic"). The original version of this loader MERGEd on
peptide_id with a single scalar `category` property, which silently
dropped every category after the first one seen for a given peptide
(confirmed via direct Cypher count: only 17,355 Peptide nodes existed
with just 8 of the expected 10 distinct categories represented at all).
This version aggregates ALL categories per unique header in Python
before loading, storing them as a list property (`categories`) instead
of a single overwritten string — so no category membership is lost.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class SATPdbLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        # First pass: aggregate all categories per unique header, since
        # the same peptide can appear in multiple category files/rows.
        by_header: dict[str, dict] = {}
        category_map: dict[str, set] = defaultdict(set)

        for rec in self.read_json(raw_path):
            header = rec.get("header")
            if not header:
                continue
            if header not in by_header:
                by_header[header] = rec
            category = rec.get("category")
            if category:
                category_map[header].add(category)

        for header, rec in by_header.items():
            yield {
                "peptide_id": f"satpdb:{header}",
                "header": header,
                "sequence": rec.get("sequence"),
                "categories": sorted(category_map[header]),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (p:Peptide {peptide_id: row.peptide_id})
              ON CREATE SET
                p.header = row.header,
                p.sequence = row.sequence,
                p.categories = row.categories,
                p.source = 'satpdb'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to satpdb/satpdb_all.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with SATPdbLoader(args.uri, args.user, args.password, "satpdb") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

"""
dbptm_loader.py — loads dbPTM (peptide-relevant post-translational
modification sites) into Neo4j.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/dbptm/dbptm_peptide_relevant_all.json
(3,205 records — confirmed to be the exact sum of the 9 individual PTM
type files: Amidation (2,260), Pyrrolidone carboxylic acid (481),
O-linked Glycosylation (215), N-linked Glycosylation (164),
Sulfation (72), Disulfide bond (6), S-linked Glycosylation (4),
C-linked Glycosylation (2), GPI-anchor (1). Only this merged file is
loaded — matches the project's Notion documentation exactly.

SCHEMA EXTENSION: :PTMSite is a new node type — one per modification
site record.

Maps onto:
  (:PTMSite {ptm_id, entry_name, uniprot_accession, position, ptm_type,
             pubmed_id, flanking_sequence, source: "dbptm"})
  (:PTMSite)-[:MODIFIES]->(:Target)
    [MATCH on Target.uniprot_id — a real, reliable connection since
     uniprot_accession here is a genuine UniProt ID, same identifier
     scheme already used throughout the graph]
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class DBPTMLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for i, rec in enumerate(self.read_json(raw_path)):
            uniprot_accession = rec.get("uniprot_accession")
            if not uniprot_accession:
                continue

            yield {
                "ptm_id": f"dbptm:{i}",
                "entry_name": rec.get("entry_name"),
                "uniprot_accession": uniprot_accession,
                "position": rec.get("position"),
                "ptm_type": rec.get("ptm_type"),
                "pubmed_id": rec.get("pubmed_id"),
                "flanking_sequence": rec.get("flanking_sequence"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (p:PTMSite {ptm_id: row.ptm_id})
              ON CREATE SET
                p.entry_name = row.entry_name,
                p.uniprot_accession = row.uniprot_accession,
                p.position = row.position,
                p.ptm_type = row.ptm_type,
                p.pubmed_id = row.pubmed_id,
                p.flanking_sequence = row.flanking_sequence,
                p.source = 'dbptm'
            WITH p, row
            MATCH (t:Target {uniprot_id: row.uniprot_accession})
            MERGE (p)-[:MODIFIES]->(t)
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to dbptm/dbptm_peptide_relevant_all.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with DBPTMLoader(args.uri, args.user, args.password, "dbptm") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

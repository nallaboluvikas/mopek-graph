"""
pdc_proteomics_loader.py — loads PDC (Proteomic Data Commons) cancer
proteomics data into Neo4j.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/pdc_proteomics_broad/pdc_all_cancer_types_peptide_genes.json
(183MB — the CORRECTED, broader version per the project's own Notion
notes: the original /pdc_proteomics/ (non-"_broad") directory used a
narrow 77-gene filter yielding only 187 matches; pdc_proteomics_broad/
re-ran against the full ~6,990-symbol UniProt-derived gene set,
yielding 32,628 matches — an intentional correction, not a duplicate.
Only pdc_proteomics_broad/ is loaded.

Each source record is:
  {"gene_symbol": str, "cancer_type": str, "pdc_study_id": str,
   "sample_values": {sample_id: float, ...}}
sample_values commonly has hundreds of individual sample measurements
per gene — this is why the file is 183MB despite "only" ~32,628
top-level records. Storing every individual sample value as its own
graph element would be excessive (tens of millions of properties); this
loader instead computes SUMMARY STATISTICS per record (mean, min, max,
sample count, tumor vs. normal breakdown based on the "_Normal"/
"_Tumor" suffix convention visible in sample IDs) rather than the raw
per-sample values. The full per-sample data remains available in the
source JSON file itself if ever needed for finer-grained analysis.

CRITICAL: this file must be loaded via SLURM (see pdc_proteomics_job.sh),
NOT run interactively on the login node — even a plain ijson streaming
peek at one record was killed there, because individual records are
large (each gene's sample_values dict can hold hundreds of key-value
pairs). Uses ijson to stream records one at a time rather than
BaseLoader.read_json(), same as gwas_bulk_loader.py and
clinicaltrials_loader.py.

SCHEMA EXTENSION: :ProteomicExpression is a new node type, added for
this data — one per (gene, cancer_type, pdc_study_id) combination.

Maps onto:
  (:Target {gene_symbol})  [MERGE — reuses existing Target nodes by
    gene_symbol if present; creates a lightweight stub otherwise,
    consistent with string_loader.py/biogrid_loader.py's pattern]
  (:ProteomicExpression {expression_id, cancer_type, pdc_study_id,
    mean_expression, min_expression, max_expression, sample_count,
    tumor_sample_count, normal_sample_count, source: "pdc"})
  (:Target)-[:HAS_PROTEOMIC_EXPRESSION]->(:ProteomicExpression)
NOTE (2026-09-22, post-load fix): ijson parses JSON numbers as Python
Decimal objects by default, NOT native float — isinstance(v, (int, float))
silently rejected every single sample value as a result, so the first
version of this loader produced sample_count=0 and no mean/min/max on
every node (confirmed directly via Cypher: tumor/normal counts, which
count dict KEYS not values, were correct at 197 total, but sample_count
and mean/min/max were 0/null). Fixed by checking for Decimal explicitly
and converting to float.
"""

from __future__ import annotations

import argparse
import statistics
from decimal import Decimal
from pathlib import Path
from typing import Iterator

import ijson

from base_loader import BaseLoader


def _summarize(sample_values: dict) -> dict:
    values = [
        float(v) for v in sample_values.values()
        if isinstance(v, (int, float, Decimal))
    ]
    tumor_count = sum(1 for k in sample_values if k.endswith("_Tumor"))
    normal_count = sum(1 for k in sample_values if k.endswith("_Normal"))
    return {
        "mean_expression": statistics.mean(values) if values else None,
        "min_expression": min(values) if values else None,
        "max_expression": max(values) if values else None,
        "sample_count": len(values),
        "tumor_sample_count": tumor_count,
        "normal_sample_count": normal_count,
    }


class PDCProteomicsLoader(BaseLoader):
    BATCH_SIZE = 500

    def parse(self, raw_path: Path) -> Iterator[dict]:
        with open(raw_path, "rb") as f:
            for rec in ijson.items(f, "item"):
                gene_symbol = rec.get("gene_symbol")
                cancer_type = rec.get("cancer_type")
                pdc_study_id = rec.get("pdc_study_id")
                sample_values = rec.get("sample_values") or {}
                if not gene_symbol or not cancer_type or not pdc_study_id:
                    continue

                summary = _summarize(sample_values)

                yield {
                    "expression_id": f"pdc:{pdc_study_id}:{gene_symbol}:{cancer_type}",
                    "gene_symbol": gene_symbol,
                    "cancer_type": cancer_type,
                    "pdc_study_id": pdc_study_id,
                    **summary,
                }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (t:Target {gene_symbol: row.gene_symbol})
              ON CREATE SET t.source = 'pdc'
            MERGE (pe:ProteomicExpression {expression_id: row.expression_id})
              SET
                pe.cancer_type = row.cancer_type,
                pe.pdc_study_id = row.pdc_study_id,
                pe.mean_expression = row.mean_expression,
                pe.min_expression = row.min_expression,
                pe.max_expression = row.max_expression,
                pe.sample_count = row.sample_count,
                pe.tumor_sample_count = row.tumor_sample_count,
                pe.normal_sample_count = row.normal_sample_count,
                pe.source = 'pdc'
            MERGE (t)-[:HAS_PROTEOMIC_EXPRESSION]->(pe)
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to pdc_proteomics_broad/pdc_all_cancer_types_peptide_genes.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with PDCProteomicsLoader(args.uri, args.user, args.password, "pdc_proteomics") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

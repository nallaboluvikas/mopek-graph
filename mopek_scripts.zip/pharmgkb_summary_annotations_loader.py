"""
pharmgkb_summary_annotations_loader.py — loads PharmGKB clinical
summary annotations into Neo4j as :PharmacogenomicAssociation nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/pharmgkb/summary_annotations.json
(50,898 records — variant/gene/drug/phenotype associations with an
evidence level and score, similar in shape to clinical_variants.json
but a much larger, more granular dataset with real unique IDs).

Maps onto:
  (:PharmacogenomicAssociation {pgx_id, variant_haplotypes, gene_symbol,
                                level_of_evidence, score, phenotype_category,
                                drugs, phenotypes, latest_history_date,
                                url, source: "pharmgkb"})
  (:PharmacogenomicAssociation)-[:ASSOCIATED_WITH_GENE]->(:Gene)
    [MATCH on Gene.symbol — same pattern as
     pharmgkb_clinical_variants_loader.py]

pgx_id is "pharmgkb:summary:" + the record's own "Summary Annotation ID"
(a real, unique identifier, unlike clinical_variants.json which had no
native per-row ID and needed a synthesized one).
NOTE (2026-08-19, post-load fix): this file is a MIXED-SCHEMA export,
not one-row-per-annotation. For each Summary Annotation ID, the FIRST
row is the real header record (Gene, Drug(s), Phenotype(s), Score,
etc.) — but subsequent rows for the SAME ID are different record types
entirely, with no field to distinguish them: genotype-specific
interpretation rows (Genotype/Allele + Annotation Text) and
history/update log rows (Date + Type + Comment). Confirmed directly:
50,898 total rows collapse to 5,190 unique annotation IDs, and 45,962
rows are missing "Gene" simply because they're not header rows at all.

This loader now aggregates all rows sharing an ID: the header row's
fields populate the main node; genotype-interpretation rows are
collected into a `genotype_interpretations` list property (as JSON
strings, same reasoning as pharmgkb_pathways_loader.py — Neo4j can't
store a list of maps directly).
"""

from __future__ import annotations

import argparse
import json as json_module
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class PharmGKBSummaryAnnotationsLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        headers_by_id: dict[str, dict] = {}
        genotypes_by_id: dict[str, list] = {}

        for rec in self.read_json(raw_path):
            annotation_id = rec.get("Summary Annotation ID")
            if not annotation_id:
                continue

            if rec.get("Gene") and annotation_id not in headers_by_id:
                headers_by_id[annotation_id] = rec

            if rec.get("Genotype/Allele"):
                genotypes_by_id.setdefault(annotation_id, []).append(json_module.dumps({
                    "genotype": rec.get("Genotype/Allele"),
                    "annotation_text": rec.get("Annotation Text"),
                    "allele_function": rec.get("Allele Function"),
                }))

        for annotation_id, rec in headers_by_id.items():
            yield {
                "pgx_id": f"pharmgkb:summary:{annotation_id}",
                "gene_symbol": rec.get("Gene"),
                "variant_haplotypes": rec.get("Variant/Haplotypes"),
                "level_of_evidence": rec.get("Level of Evidence"),
                "score": rec.get("Score"),
                "phenotype_category": rec.get("Phenotype Category"),
                "drugs": rec.get("Drug(s)"),
                "phenotypes": rec.get("Phenotype(s)"),
                "latest_history_date": rec.get("Latest History Date (YYYY-MM-DD)"),
                "url": rec.get("URL"),
                "genotype_interpretations": genotypes_by_id.get(annotation_id, []),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (pg:PharmacogenomicAssociation {pgx_id: row.pgx_id})
              ON CREATE SET
                pg.variant_haplotypes = row.variant_haplotypes,
                pg.level_of_evidence = row.level_of_evidence,
                pg.score = row.score,
                pg.phenotype_category = row.phenotype_category,
                pg.drugs = row.drugs,
                pg.phenotypes = row.phenotypes,
                pg.latest_history_date = row.latest_history_date,
                pg.url = row.url,
                pg.genotype_interpretations = row.genotype_interpretations,
                pg.source = 'pharmgkb'
            WITH pg, row
            MATCH (g:Gene {symbol: row.gene_symbol})
            MERGE (pg)-[:ASSOCIATED_WITH_GENE]->(g)
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to pharmgkb/summary_annotations.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with PharmGKBSummaryAnnotationsLoader(
        args.uri, args.user, args.password, "pharmgkb_summary_annotations"
    ) as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

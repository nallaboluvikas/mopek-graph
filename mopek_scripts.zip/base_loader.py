"""
base_loader.py — shared scaffolding for PepZen per-source loader scripts.

Each source (ChEMBL, UniProt, STRING, PDB, ...) gets its own loader that
subclasses BaseLoader and implements `parse()` and `load()`. This keeps
connection handling, batching, and logging consistent across all 38
sources instead of reinventing it per script.

Design notes:
- Loaders create ONE node per source record initially (per rollout plan
  Step 3) — they do NOT attempt to merge duplicate real-world entities
  on sight. That merging is Step 4's job (SAME_AS entity resolution),
  run as a separate pass after all sources are loaded. Keeping these
  concerns separate means a bug in matching logic can't corrupt the
  raw loaded data, and resolution can be re-run/improved without
  re-loading everything.
- MERGE (not CREATE) is used per-node so a loader can be safely re-run
  after a partial failure without creating duplicate nodes from the
  same source.
"""

from __future__ import annotations

import json
import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Iterable, Iterator

from neo4j import GraphDatabase, Driver

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)


class BaseLoader(ABC):
    """Subclass per source. See loaders/chembl_loader.py for a worked example."""

    #: batch size for UNWIND-based writes — tune per source if records are large
    BATCH_SIZE = 500

    def __init__(self, uri: str, user: str, password: str, source_name: str):
        self.driver: Driver = GraphDatabase.driver(uri, auth=(user, password))
        self.source_name = source_name
        self.log = logging.getLogger(source_name)

    def close(self) -> None:
        self.driver.close()

    def __enter__(self) -> "BaseLoader":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Override these two in each per-source loader
    # ------------------------------------------------------------------

    @abstractmethod
    def parse(self, raw_path: Path) -> Iterator[dict]:
        """Yield one dict per source record, already field-mapped onto
        this source's slice of the schema (see schema.cypher + the
        node/edge reference table in the project doc)."""
        raise NotImplementedError

    @abstractmethod
    def load_batch(self, tx, batch: list[dict]) -> None:
        """Given a batch of parsed records, run the MERGE/CREATE Cypher
        for this source's node + relationship types."""
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Shared driver logic — usually no need to override
    # ------------------------------------------------------------------

    def run(self, raw_path: Path) -> None:
        self.log.info("Starting load from %s", raw_path)
        total = 0
        batch: list[dict] = []

        for record in self.parse(raw_path):
            batch.append(record)
            if len(batch) >= self.BATCH_SIZE:
                self._write_batch(batch)
                total += len(batch)
                self.log.info("Loaded %d records so far", total)
                batch = []

        if batch:
            self._write_batch(batch)
            total += len(batch)

        self.log.info("Done. %d records loaded from %s", total, self.source_name)

    def _write_batch(self, batch: list[dict]) -> None:
        with self.driver.session() as session:
            session.execute_write(self.load_batch, batch)

    @staticmethod
    def read_json(path: Path) -> Iterable[dict]:
        """Handles both a JSON array file and JSON-lines files."""
        text = path.read_text().strip()
        if text.startswith("["):
            yield from json.loads(text)
        else:
            for line in text.splitlines():
                if line.strip():
                    yield json.loads(line)

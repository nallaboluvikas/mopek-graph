"""
pcawg_drivers_loader.py — loads PCAWG cancer driver mutation records
into Neo4j.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/pcawg_drivers/pcawg_driver_mutations_peptide_genes.json
(49 records — sample-level cancer driver mutation calls).

SCHEMA EXTENSION: :DriverMutation is a new node type.

Maps onto:
  (:DriverMutation {mutation_id, sample_id, tumor_type, chr, pos, ref,
                     alt, driver_status, driver_statement, category,
                     top_category, biallelic, source: "pcawg"})
  (:DriverMutation)-[:DRIVER_IN_GENE]->(:Gene)
    [MATCH on Gene.symbol]

mutation_id is synthesized (sample_id + gene, since there's no other
natural per-row identifier in this dataset).
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class PCAWGDriversLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            sample_id = rec.get("sample_id")
            gene = rec.get("gene")
            if not sample_id or not gene:
                continue

            yield {
                "mutation_id": f"pcawg:{sample_id}:{gene}",
                "gene_symbol": gene,
                "sample_id": sample_id,
                "tumor_type": rec.get("ttype"),
                "chr": rec.get("chr"),
                "pos": rec.get("pos"),
                "ref": rec.get("ref"),
                "alt": rec.get("alt"),
                "driver_status": rec.get("driver"),
                "driver_statement": rec.get("driver_statement"),
                "category": rec.get("category"),
                "top_category": rec.get("top_category"),
                "biallelic": rec.get("biallelic"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (dm:DriverMutation {mutation_id: row.mutation_id})
              ON CREATE SET
                dm.sample_id = row.sample_id,
                dm.tumor_type = row.tumor_type,
                dm.chr = row.chr,
                dm.pos = row.pos,
                dm.ref = row.ref,
                dm.alt = row.alt,
                dm.driver_status = row.driver_status,
                dm.driver_statement = row.driver_statement,
                dm.category = row.category,
                dm.top_category = row.top_category,
                dm.biallelic = row.biallelic,
                dm.source = 'pcawg'
            WITH dm, row
            MATCH (g:Gene {symbol: row.gene_symbol})
            MERGE (dm)-[:DRIVER_IN_GENE]->(g)
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to pcawg_drivers/pcawg_driver_mutations_peptide_genes.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with PCAWGDriversLoader(args.uri, args.user, args.password, "pcawg") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

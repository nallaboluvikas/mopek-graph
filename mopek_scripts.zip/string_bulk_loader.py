"""
string_bulk_loader.py — loads STRING bulk protein-protein interactions
(pre-filtered to peptide-relevant genes) into Neo4j.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/string_bulk/peptide_interactions.json
(20,044 records — already extracted/filtered from STRING's full human
interactome bulk download (9606.protein.links.v12.0.txt.gz, the raw
.gz files in this directory); this loader only reads the pre-processed
JSON, not the raw STRING bulk files directly).

Maps onto:
  (:Target)-[:INTERACTS_WITH {score, string_id_a, string_id_b,
                              source: "string_bulk"}]->(:Target)

Score here is on STRING's native 0-1000 combined-confidence scale
(unlike the smaller string_loader.py/interactions_expanded, which use
a 0-1 scale) — left as-is, not normalized, since that's how STRING
itself reports it for this particular data product.

Uses MERGE on (string_id_a, string_id_b) as part of the relationship's
key — learned from this session's earlier BioGRID/IntAct
duplicate-relationship lesson: without a distinguishing key beyond the
two endpoint nodes, re-running this loader (or encountering the same
gene pair via multiple STRING protein-ID combinations) could silently
collapse or duplicate edges.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class StringBulkLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            gene_a = rec.get("gene_a")
            gene_b = rec.get("gene_b")
            if not gene_a or not gene_b:
                continue

            yield {
                "gene_a": gene_a,
                "gene_b": gene_b,
                "string_id_a": rec.get("protein_a"),
                "string_id_b": rec.get("protein_b"),
                "score": rec.get("score"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (a:Target {gene_symbol: row.gene_a})
              ON CREATE SET a.source = 'string_bulk'
            MERGE (b:Target {gene_symbol: row.gene_b})
              ON CREATE SET b.source = 'string_bulk'
            MERGE (a)-[r:INTERACTS_WITH {string_id_a: row.string_id_a, string_id_b: row.string_id_b}]->(b)
              SET r.score = row.score,
                  r.source = 'string_bulk'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to string_bulk/peptide_interactions.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with StringBulkLoader(args.uri, args.user, args.password, "string_bulk") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

"""
gwas_bulk_loader.py — loads the full GWAS Catalog v1.0.2 bulk dataset
into Neo4j.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/gwas_bulk/gwas_full_v102.json
(412MB, 1,150,105 records — confirmed via streaming count, matches the
project's Notion documentation exactly).

CRITICAL: this file is far too large to json.load() into memory like
every other loader this session. Uses ijson to stream records one at
a time, so memory usage stays flat regardless of file size — the
BaseLoader.read_json() helper used everywhere else in this project
does NOT do this (it reads the whole file), so this loader overrides
parse() to stream directly instead of calling read_json().

Maps onto:
  (:Variant {variant_id, rsid, chromosome, position, source: "gwas"})
  (:Gene {symbol, gene_symbol_only: true, source: "gwas"})
    [MERGE — many GWAS "gene" values are actually intergenic pairs
     like "GENE1 - GENE2" or non-coding RNA names; these are still
     captured as-is on a Gene-labeled node via MERGE on symbol, but
     flagged with gene_symbol_only=true since they may not correspond
     to a clean single NCBI gene the way pharmgkb_genes_loader.py's
     nodes do. No uniqueness constraint conflict: Gene's constraint is
     on ncbi_gene_id, which these nodes never set, so they coexist
     safely alongside PharmGKB's richer Gene nodes without violating
     anything — but also without automatically merging with them
     unless symbols happen to match via a future entity-resolution
     pass.]
  (:Phenotype {pharmgkb_id: "gwas:" + disease_trait, name: disease_trait,
               mapped_trait, source: "gwas"})
    [reuses the :Phenotype node type added for PharmGKB — pharmgkb_id
     here is a synthesized key based on the trait NAME itself, since
     GWAS Catalog traits have no PharmGKB accession; this means the
     same trait name appearing verbatim elsewhere would correctly
     collide/merge, but near-duplicate trait names (e.g. slightly
     different wording for the same real trait) will NOT auto-merge —
     a known limitation, same category as other cross-source identity
     gaps this session, left for a future entity-resolution pass]
  (:Variant)-[:ASSOCIATED_WITH_TRAIT {pvalue, or_beta, pubmed_id,
                                      accession, source: "gwas"}]
           ->(:Phenotype)
  (:Variant)-[:LOCATED_IN_GENE]->(:Gene)
    [only created when a gene value looks like a single clean symbol,
     not an intergenic "X - Y" pair or empty string]

BATCH_SIZE is reduced from the default 500 to 2000 for this loader,
since GWAS records are small/flat and 1.15M records at 500/batch would
mean 2,300+ round trips — 2000/batch cuts that to ~575, meaningfully
faster for a file this size without risking oversized transactions.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

import ijson

from base_loader import BaseLoader


def _looks_like_single_gene(gene_field: str) -> bool:
    if not gene_field:
        return False
    if " - " in gene_field:
        return False  # intergenic pair, e.g. "GENE1 - GENE2"
    if "," in gene_field:
        return False  # multiple genes listed
    return True


class GWASBulkLoader(BaseLoader):
    BATCH_SIZE = 2000

    def parse(self, raw_path: Path) -> Iterator[dict]:
        with open(raw_path, "rb") as f:
            for rec in ijson.items(f, "item"):
                snp = rec.get("snp")
                disease_trait = rec.get("disease_trait")
                if not snp or not disease_trait:
                    continue

                gene_field = rec.get("gene") or ""
                clean_gene = gene_field.strip() if _looks_like_single_gene(gene_field) else None

                yield {
                    "variant_id": f"gwas:{snp}",
                    "rsid": snp,
                    "chromosome": rec.get("chr"),
                    "position": rec.get("pos"),
                    "gene_symbol": clean_gene,
                    "phenotype_id": f"gwas:{disease_trait}",
                    "disease_trait": disease_trait,
                    "mapped_trait": rec.get("mapped_trait"),
                    "pvalue": rec.get("pvalue"),
                    "or_beta": rec.get("or_beta"),
                    "pubmed_id": rec.get("pubmed_id"),
                    "accession": rec.get("accession"),
                }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (v:Variant {variant_id: row.variant_id})
              ON CREATE SET
                v.rsid = row.rsid,
                v.chromosome = row.chromosome,
                v.position = row.position,
                v.source = 'gwas'
            MERGE (ph:Phenotype {pharmgkb_id: row.phenotype_id})
              ON CREATE SET
                ph.name = row.disease_trait,
                ph.mapped_trait = row.mapped_trait,
                ph.source = 'gwas'
            MERGE (v)-[a:ASSOCIATED_WITH_TRAIT {accession: row.accession}]->(ph)
              SET a.pvalue = row.pvalue,
                  a.or_beta = row.or_beta,
                  a.pubmed_id = row.pubmed_id,
                  a.source = 'gwas'
            WITH v, row
            WHERE row.gene_symbol IS NOT NULL
            MERGE (g:Gene {symbol: row.gene_symbol})
              ON CREATE SET g.gene_symbol_only = true, g.source = 'gwas'
            MERGE (v)-[:LOCATED_IN_GENE]->(g)
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to gwas_bulk/gwas_full_v102.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with GWASBulkLoader(args.uri, args.user, args.password, "gwas_bulk") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

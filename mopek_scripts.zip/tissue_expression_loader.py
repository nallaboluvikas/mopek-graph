"""
tissue_expression_loader.py — loads tissue/epigenome expression data
from multiple sources into Neo4j as :TissueExpression nodes. Handles
5 related sources via --mode, since they share a common shape (gene +
tissue-or-epigenome + expression value):

  --mode gtex           data/gtex/expression.json (5,238 records, one
                         row per gene-tissue pair already)
  --mode gtex_v11        data/gtex_v11/gtex_v11_peptide_expression.json
                         (77 records, but each has a NESTED
                         tissue_median_tpm dict with ~68 tissues per
                         gene — expanded here into one TissueExpression
                         node per gene-tissue pair)
  --mode hpa_transcript  data/transcriptomics/expression.json (3,045
                         records, HPA transcriptomics — has a real
                         uniprot field for direct Target linkage)
  --mode hpa_protein     data/proteomics/protein_expression.json (43
                         records, HPA protein — same shape as
                         hpa_transcript but no uniprot field)
  --mode roadmap         data/roadmap_epigenomics/roadmap_peptide_expression.json
                         (74 records, nested epigenome_rpkm dict per
                         gene — same expansion treatment as gtex_v11)

SCHEMA EXTENSION: :TissueExpression is a new node type.

Maps onto:
  (:TissueExpression {expression_id, tissue, expression_value,
                       dataset, source})
  (:Target)-[:HAS_TISSUE_EXPRESSION]->(:TissueExpression)
    [MERGE on Target.gene_symbol — creates a stub if no existing
     Target matches, consistent with earlier loaders' pattern for
     gene-symbol-keyed connections]
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class TissueExpressionLoader(BaseLoader):
    def __init__(self, uri, user, password, source_name, mode: str):
        super().__init__(uri, user, password, source_name)
        self.mode = mode

    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            if self.mode == "gtex":
                gene = rec.get("gene")
                if not gene:
                    continue
                yield {
                    "expression_id": f"gtex:{rec.get('gencode_id')}:{rec.get('tissue')}",
                    "gene_symbol": gene,
                    "tissue": rec.get("tissue"),
                    "expression_value": rec.get("median_tpm"),
                    "dataset": rec.get("dataset"),
                }

            elif self.mode == "gtex_v11":
                gene = rec.get("gene_symbol")
                ensembl_id = rec.get("ensembl_id")
                tissue_map = rec.get("tissue_median_tpm") or {}
                if not gene:
                    continue
                for tissue, value in tissue_map.items():
                    yield {
                        "expression_id": f"gtex_v11:{ensembl_id}:{tissue}",
                        "gene_symbol": gene,
                        "tissue": tissue,
                        "expression_value": value,
                        "dataset": "GTEx v11",
                    }

            elif self.mode == "hpa_transcript":
                gene = rec.get("gene")
                if not gene:
                    continue
                yield {
                    "expression_id": f"hpa_rna:{rec.get('ensembl_id')}:{rec.get('tissue')}",
                    "gene_symbol": gene,
                    "tissue": rec.get("tissue"),
                    "expression_value": rec.get("expression_nTPM"),
                    "dataset": "HPA transcriptomics",
                }

            elif self.mode == "hpa_protein":
                gene = rec.get("gene")
                if not gene:
                    continue
                yield {
                    "expression_id": f"hpa_protein:{rec.get('ensembl_id')}:{rec.get('tissue')}",
                    "gene_symbol": gene,
                    "tissue": rec.get("tissue"),
                    "expression_value": rec.get("expression_nTPM"),
                    "dataset": "HPA protein",
                }

            elif self.mode == "roadmap":
                gene = rec.get("gene_symbol")
                ensembl_id = rec.get("ensembl_id")
                epigenome_map = rec.get("epigenome_rpkm") or {}
                if not gene:
                    continue
                for epigenome, value in epigenome_map.items():
                    yield {
                        "expression_id": f"roadmap:{ensembl_id}:{epigenome}",
                        "gene_symbol": gene,
                        "tissue": epigenome,
                        "expression_value": value,
                        "dataset": "Roadmap Epigenomics",
                    }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (te:TissueExpression {expression_id: row.expression_id})
              ON CREATE SET
                te.tissue = row.tissue,
                te.expression_value = row.expression_value,
                te.dataset = row.dataset,
                te.source = $source_name
            WITH te, row
            MERGE (t:Target {gene_symbol: row.gene_symbol})
              ON CREATE SET t.source = $source_name
            MERGE (t)-[:HAS_TISSUE_EXPRESSION]->(te)
            """,
            batch=batch,
            source_name=self.source_name,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path)
    ap.add_argument("--mode", required=True, choices=["gtex", "gtex_v11", "hpa_transcript", "hpa_protein", "roadmap"])
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with TissueExpressionLoader(args.uri, args.user, args.password, args.mode, args.mode) as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

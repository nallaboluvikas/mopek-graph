"""
pharmgkb_drugs_loader.py — loads PharmGKB drug records into Neo4j as
:Drug nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/pharmgkb/drugs.json

SCHEMA EXTENSION (2026-08-18): :Drug is not one of the original node
types in schema.cypher — it was added specifically to accommodate this
data. See the schema.cypher extension block for the constraint/index
added alongside this loader. This is PharmGKB's general drug vocabulary
(small molecules + biologics), not peptide-specific — most entries here
are NOT peptides.

Maps onto:
  (:Drug {pharmgkb_id, name, generic_names, trade_names, drug_type,
          smiles, inchi, pubchem_cid, rxnorm_ids, atc_ids,
          source: "pharmgkb"})

No relationship to Peptide is created here (most PharmGKB drugs aren't
peptides at all, so a peptide link isn't generally meaningful). This
DOES set up a future (:PharmacogenomicAssociation)-[:INVOLVES_DRUG]->
(:Drug) link — matching PharmacogenomicAssociation.chemicals (currently
a loose text field) against Drug.name — as a follow-up entity-resolution
task, not done in this loader.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class PharmGKBDrugsLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            pharmgkb_id = rec.get("PharmGKB Accession Id")
            if not pharmgkb_id:
                continue  # skip records with no usable identifier

            yield {
                "pharmgkb_id": pharmgkb_id,
                "name": rec.get("Name"),
                "generic_names": rec.get("Generic Names"),
                "trade_names": rec.get("Trade Names"),
                "drug_type": rec.get("Type"),
                "smiles": rec.get("SMILES"),
                "inchi": rec.get("InChI"),
                "pubchem_cid": rec.get("PubChem Compound Identifiers"),
                "rxnorm_ids": rec.get("RxNorm Identifiers"),
                "atc_ids": rec.get("ATC Identifiers"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (d:Drug {pharmgkb_id: row.pharmgkb_id})
              ON CREATE SET
                d.name = row.name,
                d.generic_names = row.generic_names,
                d.trade_names = row.trade_names,
                d.drug_type = row.drug_type,
                d.smiles = row.smiles,
                d.inchi = row.inchi,
                d.pubchem_cid = row.pubchem_cid,
                d.rxnorm_ids = row.rxnorm_ids,
                d.atc_ids = row.atc_ids,
                d.source = 'pharmgkb'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to pharmgkb/drugs.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with PharmGKBDrugsLoader(args.uri, args.user, args.password, "pharmgkb_drugs") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

"""
chembl_bioactivity_loader.py — loads ChEMBL peptide-target bioactivity
data into Neo4j, finally closing the BINDS gap flagged in the earlier
chembl_loader.py (which found 0 bioactivities in the /home/ copy).

Reads:
  /projects/pbpk/vikas/pepzen/data_collection/data/chembl/bioactivities.json
    (1,839 records — the real ChEMBL API bioactivity pull; the /home/
    copy of this same file was empty, confirmed earlier this session
    to be caused by the helm_notation molecule filter selecting
    peptides with no assay data. Whatever fixed that between then and
    when /projects/'s version was collected, this one has real data.)
  /projects/pbpk/vikas/pepzen/data_collection/data/chembl_bulk/chembl_uniprot_mapping.json
    (17,257 records — maps ChEMBL target IDs to UniProt accessions)

NOTE on the mapping file's field names: they are swapped from what
they claim to be. Its "chembl_id" field actually holds a UniProt
accession (e.g. "P21266"), and its "uniprot_id" field actually holds
a ChEMBL target ID (e.g. "CHEMBL2242") — verified by inspecting the
value formats directly. This loader reads them with that swap
corrected; do not trust the field names literally if reusing this
mapping file elsewhere.

Maps onto:
  (:Peptide)-[:BINDS {activity_id, ic50, ki, standard_type,
                      standard_value, standard_units, assay_type,
                      source: "chembl"}]->(:Target)

NOTE (2026-08-18, post-load fix): activity_id is included in the
relationship's MERGE key. Without it, MERGE (p)-[:BINDS]->(t) collapses
multiple distinct assay records for the same peptide-target pair into
a single relationship (only the last-processed assay's properties
survive) — caught by comparing the loader's "records loaded" count
(692) against the actual relationship count in Neo4j (0, then still
undercounted before this fix). Keying on activity_id preserves each
assay as its own relationship.

Uses MATCH (not MERGE) for the Peptide side, matched on the Peptide.chembl_id
PROPERTY (e.g. "CHEMBL448105") — not peptide_id, which is instead a
PepZen-internal ID like "chembl:PZ-CHL-2D08DB8F" and does NOT contain
the raw ChEMBL accession. (An earlier version of this loader incorrectly
tried to build peptide_id from the raw chembl_id and matched nothing —
verified via a direct Neo4j query before this fix.) If a bioactivity's
chembl_id doesn't resolve to an existing Peptide (possible if
bioactivities.json covers a different/broader molecule set than
chembl_normalized.json), that record is skipped and counted, not
silently dropped without a trace — check the final log's
skipped-record count.

Uses MERGE for the Target side, same pattern as other loaders, so it
attaches to existing UniProt-sourced Target nodes where possible and
creates stubs otherwise.

Records whose target_chembl_id has no entry in the mapping file are
skipped (the mapping only covers 17,257 of ChEMBL's targets — not
necessarily exhaustive).
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class ChemblBioactivityLoader(BaseLoader):
    def __init__(self, uri, user, password, source_name, mapping_path: Path):
        super().__init__(uri, user, password, source_name)
        self.target_map = self._load_mapping(mapping_path)
        self.skipped_no_mapping = 0

    @staticmethod
    def _load_mapping(mapping_path: Path) -> dict:
        raw = json.loads(mapping_path.read_text())
        # NOTE: fields are swapped in the source file — see module docstring.
        # raw "uniprot_id" field actually holds the ChEMBL target ID (key),
        # raw "chembl_id" field actually holds the real UniProt accession (value).
        mapping = {}
        for rec in raw:
            chembl_target_id = rec.get("uniprot_id")  # actually a CHEMBL ID
            uniprot_accession = rec.get("chembl_id")   # actually a UniProt accession
            if chembl_target_id and uniprot_accession:
                mapping[chembl_target_id] = uniprot_accession
        return mapping

    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            chembl_id = rec.get("chembl_id")
            target_chembl_id = rec.get("target_chembl_id")
            if not chembl_id or not target_chembl_id:
                continue

            uniprot_id = self.target_map.get(target_chembl_id)
            if not uniprot_id:
                self.skipped_no_mapping += 1
                continue  # no known UniProt mapping for this ChEMBL target

            yield {
                "activity_id": rec.get("activity_id"),
                "chembl_id": chembl_id,
                "uniprot_id": uniprot_id,
                "target_name": rec.get("target_name"),
                "standard_type": rec.get("standard_type"),
                "standard_value": rec.get("standard_value"),
                "standard_units": rec.get("standard_units"),
                "standard_relation": rec.get("standard_relation"),
                "assay_type": rec.get("assay_type"),
                "ic50": rec.get("standard_value") if rec.get("standard_type") == "IC50" else None,
                "ki": rec.get("standard_value") if rec.get("standard_type") == "Ki" else None,
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MATCH (p:Peptide {chembl_id: row.chembl_id})
            MERGE (t:Target {uniprot_id: row.uniprot_id})
              ON CREATE SET t.gene_symbol = row.target_name, t.source = 'chembl'
            MERGE (p)-[b:BINDS {activity_id: row.activity_id}]->(t)
              SET b.target_name = row.target_name,
                  b.standard_type = row.standard_type,
                  b.standard_value = row.standard_value,
                  b.standard_units = row.standard_units,
                  b.standard_relation = row.standard_relation,
                  b.assay_type = row.assay_type,
                  b.ic50 = row.ic50,
                  b.ki = row.ki,
                  b.source = 'chembl'
            """,
            batch=batch,
        )

    def run(self, raw_path: Path) -> None:
        super().run(raw_path)
        self.log.info(
            "Skipped %d records with no ChEMBL target -> UniProt mapping",
            self.skipped_no_mapping,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to chembl/bioactivities.json")
    ap.add_argument("--mapping", type=Path, required=True, help="Path to chembl_uniprot_mapping.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with ChemblBioactivityLoader(
        args.uri, args.user, args.password, "chembl_bioactivity", args.mapping
    ) as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

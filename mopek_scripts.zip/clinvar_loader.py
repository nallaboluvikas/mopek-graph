"""
clinvar_loader.py — loads ClinVar variant records into Neo4j as
:Variant nodes, reusing the existing Variant node type (already
populated by pharmgkb_guideline_annotations_loader.py's rsID-based
stubs and gwas_bulk_loader.py's "gwas:"-prefixed variants).

Handles TWO source files via --source, since they were confirmed to
overlap (202 of 447 genomics_variants records also appear in
clinvar_full) but are NOT a clean subset of each other (245 records
exist only in genomics_variants):

  --source clinvar_full   data/clinvar_full/variants_full.json (2,295)
  --source genomics       data/genomics/variants.json (447)

Both use the same underlying ClinVar variant_id scheme, so both are
loaded with the SAME "clinvar:" + variant_id key via MERGE — running
clinvar_full first, then genomics second, means the 202 overlapping
records simply get re-matched (harmless), while genomics contributes
its 245 unique records as new nodes.

Maps onto:
  (:Variant {variant_id, title, gene_symbol, clinical_significance,
             review_status, variation_type, disease, url,
             source: "clinvar"})
  (:Variant)-[:VARIANT_IN_GENE]->(:Gene)
    [MATCH on Gene.symbol]
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class ClinVarLoader(BaseLoader):
    def __init__(self, uri, user, password, source_name, file_kind: str):
        super().__init__(uri, user, password, source_name)
        self.file_kind = file_kind

    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            variant_id = rec.get("variant_id")
            if not variant_id:
                continue

            if self.file_kind == "clinvar_full":
                clinical_sig = rec.get("clinical_sig")
            else:
                clinical_sig = rec.get("clinical_significance")

            yield {
                "variant_id": f"clinvar:{variant_id}",
                "title": rec.get("title"),
                "gene_symbol": rec.get("gene"),
                "clinical_significance": clinical_sig,
                "review_status": rec.get("review_status"),
                "variation_type": rec.get("variation_type"),
                "disease": rec.get("disease"),
                "url": rec.get("url"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (v:Variant {variant_id: row.variant_id})
              ON CREATE SET
                v.title = row.title,
                v.clinical_significance = row.clinical_significance,
                v.review_status = row.review_status,
                v.variation_type = row.variation_type,
                v.disease = row.disease,
                v.url = row.url,
                v.source = 'clinvar'
            WITH v, row
            WHERE row.gene_symbol IS NOT NULL
            MATCH (g:Gene {symbol: row.gene_symbol})
            MERGE (v)-[:VARIANT_IN_GENE]->(g)
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path)
    ap.add_argument("--source", required=True, choices=["clinvar_full", "genomics"])
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with ClinVarLoader(args.uri, args.user, args.password, "clinvar", args.source) as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

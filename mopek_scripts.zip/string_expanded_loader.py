"""
string_expanded_loader.py — loads STRING "expanded" protein-protein
interactions into Neo4j (with per-evidence-type score breakdown).

Reads /projects/pbpk/vikas/pepzen/data_collection/data/string_expanded/interactions_expanded.json
(4,926 records).

Maps onto:
  (:Target)-[:INTERACTS_WITH {score, experimental, coexpression,
                              database, textmining, string_id_a,
                              string_id_b, source: "string_expanded"}]
           ->(:Target)

Score here is on the 0-1 scale (unlike string_bulk_loader.py's 0-1000
scale) — same field structure as the original small string_loader.py
from earlier this session, just a much larger dataset.

Uses MERGE on (string_id_a, string_id_b) as part of the relationship
key, same duplicate-prevention reasoning as string_bulk_loader.py.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class StringExpandedLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            gene_a = rec.get("protein_a")
            gene_b = rec.get("protein_b")
            if not gene_a or not gene_b:
                continue

            yield {
                "gene_a": gene_a,
                "gene_b": gene_b,
                "string_id_a": rec.get("string_id_a"),
                "string_id_b": rec.get("string_id_b"),
                "score": rec.get("score"),
                "experimental": rec.get("experimental"),
                "coexpression": rec.get("coexpression"),
                "database": rec.get("database"),
                "textmining": rec.get("textmining"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (a:Target {gene_symbol: row.gene_a})
              ON CREATE SET a.source = 'string_expanded'
            MERGE (b:Target {gene_symbol: row.gene_b})
              ON CREATE SET b.source = 'string_expanded'
            MERGE (a)-[r:INTERACTS_WITH {string_id_a: row.string_id_a, string_id_b: row.string_id_b}]->(b)
              SET r.score = row.score,
                  r.experimental = row.experimental,
                  r.coexpression = row.coexpression,
                  r.database = row.database,
                  r.textmining = row.textmining,
                  r.source = 'string_expanded'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to string_expanded/interactions_expanded.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with StringExpandedLoader(args.uri, args.user, args.password, "string_expanded") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

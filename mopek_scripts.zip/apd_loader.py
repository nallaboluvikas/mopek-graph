"""
apd_loader.py — loads APD (Antimicrobial Peptide Database) sequences
into Neo4j as :Peptide nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/apd/apd_all.json
(3,307 total records). apd_natural.json is byte-for-byte identical
(confirmed via `diff`, exit code 0) — only apd_all.json is loaded.

NOTE: record 0 in the source file is a scraping artifact, not real
peptide data — {"header": "Your search led to 3306 peptides",
"sequence": "", "category": "natural"} — the page's own result-count
message got captured as if it were an entry. This loader skips any
record with an empty sequence, which correctly filters out just this
one artifact row (confirmed: 3,306 of 3,307 records have a real,
non-empty sequence).

Maps onto:
  (:Peptide {peptide_id, header, sequence, category, source: "apd"})
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class APDLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            header = rec.get("header")
            sequence = rec.get("sequence")
            if not header or not sequence:
                continue  # skips the "Your search led to..." artifact row

            yield {
                "peptide_id": f"apd:{header}",
                "header": header,
                "sequence": sequence,
                "category": rec.get("category"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (p:Peptide {peptide_id: row.peptide_id})
              ON CREATE SET
                p.header = row.header,
                p.sequence = row.sequence,
                p.category = row.category,
                p.source = 'apd'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to apd/apd_all.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with APDLoader(args.uri, args.user, args.password, "apd") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

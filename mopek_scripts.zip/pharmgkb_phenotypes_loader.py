"""
pharmgkb_phenotypes_loader.py — loads PharmGKB phenotype records into
Neo4j as :Phenotype nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/pharmgkb/phenotypes.json
(1,619 records).

SCHEMA EXTENSION (2026-08-19): :Phenotype is not one of the original
node types — added alongside :Drug and :Metabolite. PharmGKB's
phenotype vocabulary is broader than the schema's existing :Disease
node (includes symptoms and drug-response outcomes like "Abdominal
Pain", not just diagnosable diseases), and these records have no EFO
ID (Disease.efo_id's required field) — only MeSH/SnoMedCT/UMLS/MedDRA/
NDFRT/HP cross-references. Using a dedicated node type with PharmGKB's
own accession as the key avoids forcing a semantic mismatch onto
:Disease.

Maps onto:
  (:Phenotype {pharmgkb_id, name, alternate_names, cross_references,
               external_vocabulary, source: "pharmgkb"})
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class PharmGKBPhenotypesLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            pharmgkb_id = rec.get("PharmGKB Accession Id")
            if not pharmgkb_id:
                continue

            yield {
                "pharmgkb_id": pharmgkb_id,
                "name": rec.get("Name"),
                "alternate_names": rec.get("Alternate Names"),
                "cross_references": rec.get("Cross-references"),
                "external_vocabulary": rec.get("External Vocabulary"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (ph:Phenotype {pharmgkb_id: row.pharmgkb_id})
              ON CREATE SET
                ph.name = row.name,
                ph.alternate_names = row.alternate_names,
                ph.cross_references = row.cross_references,
                ph.external_vocabulary = row.external_vocabulary,
                ph.source = 'pharmgkb'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to pharmgkb/phenotypes.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with PharmGKBPhenotypesLoader(args.uri, args.user, args.password, "pharmgkb_phenotypes") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

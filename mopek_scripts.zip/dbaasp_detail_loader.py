"""
dbaasp_detail_loader.py — loads DBAASP Phase 2 full-detail data
(data/dbaasp/dbaasp_detail.json, collected by dbaasp_collector.py
--phase detail) into Neo4j, enriching the Peptide nodes already
created by dbaasp_loader.py (Phase 1).

This is the genuinely high-value part of DBAASP's data: real UniProt
IDs (direct link to existing :Target nodes, same identifier scheme
already used throughout the graph) and real PubMed IDs (direct link
to existing :Publication nodes) — plus quantitative target activity
data that DRAMP's own "Binding_Traget" field (loaded earlier this
project) only captured as free text.

Maps onto:
  Peptide (existing dbaasp: nodes) enriched with:
    major_name, synthesis_type, note_reference, url
  (:Peptide)-[:BINDS]->(:Target)
    [MATCH on Target.uniprot_id, from each peptide's `uniprots` array]
  (:Peptide)-[:CITES]->(:Publication)
    [MATCH on Publication.pmid, from each peptide's `articles` array]
  (:Peptide)-[:HAS_MECHANISM_TARGET]->(:MechanismTarget)
    [MERGE on targetObjects' names — same node type used for DRAMP's
     mechanism data, so DBAASP's target objects (e.g. "Cell membrane")
     cluster together with DRAMP's if they share a name, extending
     Use Case 3's mechanism-based clustering with a second real source]

Uses MATCH (not MERGE) for Target/Publication connections, consistent
with this project's established pattern: a missing match here means
the UniProt/PubMed ID isn't in the graph yet, not that we should
create a stub for every reference.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class DBAASPDetailLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            peptide_id = rec.get("id")
            if peptide_id is None:
                continue

            uniprot_ids = [
                u.get("uniprotId") for u in (rec.get("uniprots") or [])
                if u.get("uniprotId")
            ]
            pmids = [
                a.get("pubmed", {}).get("pubmedId") for a in (rec.get("articles") or [])
                if a.get("pubmed") and a["pubmed"].get("pubmedId")
            ]
            mechanism_names = [
                t.get("name") for t in (rec.get("targetObjects") or [])
                if t.get("name")
            ]

            yield {
                "peptide_id": f"dbaasp:{peptide_id}",
                "major_name": rec.get("majorName"),
                "synthesis_type": (rec.get("synthesisType") or {}).get("name"),
                "note_reference": rec.get("noteReference"),
                "url": rec.get("url"),
                "uniprot_ids": uniprot_ids,
                "pmids": pmids,
                "mechanism_names": [m.strip().lower() for m in mechanism_names],
                "mechanism_display": mechanism_names,
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MATCH (p:Peptide {peptide_id: row.peptide_id})
            SET p.major_name = row.major_name,
                p.synthesis_type = row.synthesis_type,
                p.note_reference = row.note_reference,
                p.url = row.url
            WITH p, row
            UNWIND row.uniprot_ids AS uid
            MATCH (t:Target {uniprot_id: uid})
            MERGE (p)-[b:BINDS]->(t)
              SET b.source = 'dbaasp'
            """,
            batch=batch,
        )
        tx.run(
            """
            UNWIND $batch AS row
            MATCH (p:Peptide {peptide_id: row.peptide_id})
            UNWIND row.pmids AS pmid
            MATCH (pub:Publication {pmid: pmid})
            MERGE (p)-[:CITES]->(pub)
            """,
            batch=batch,
        )
        tx.run(
            """
            UNWIND $batch AS row
            MATCH (p:Peptide {peptide_id: row.peptide_id})
            UNWIND range(0, size(row.mechanism_names) - 1) AS i
            WITH p, row.mechanism_names[i] AS mech_key, row.mechanism_display[i] AS mech_name
            MERGE (mt:MechanismTarget {mechanism_id: mech_key})
              ON CREATE SET mt.name = mech_name, mt.source = 'dbaasp'
            MERGE (p)-[:HAS_MECHANISM_TARGET]->(mt)
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to dbaasp/dbaasp_detail.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with DBAASPDetailLoader(args.uri, args.user, args.password, "dbaasp_detail") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

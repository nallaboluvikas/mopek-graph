"""
opentargets_collector_broad.py — re-collects OpenTargets gene-disease
association data against the FULL peptide gene set, correcting the
same narrow-gene-list problem already found and fixed once this
project for PDC proteomics.

The original disease/opentargets.json only queried 46 genes (confirmed
directly), yielding disease data for just 26 of them — this is why
Use Case 1 (drug repurposing) failed validation: none of the
approved-peptide-connected targets happened to be among those 46.

Reuses the IDENTICAL gene-list-broadening function from
pdc_proteomics_collector.py (load_peptide_gene_symbols), reading
data/uniprot/entries.json's `gene_names` field — the same ~6,990-symbol
UniProt-derived set already used to fix PDC's under-collection
(187 -> 32,628 matches, documented in the project's Notion page).

Queries the real, public OpenTargets Platform GraphQL API
(https://api.platform.opentargets.org/api/v4/graphql, confirmed via
web search 2026-09-22 — no API key required). OpenTargets targets are
keyed by Ensembl gene ID, not gene symbol, so this collector first
resolves each gene SYMBOL to an Ensembl ID via OpenTargets' own
`target` search-by-symbol capability (the `search` query), then
fetches associatedDiseases for each resolved target.

Given ~6,990 genes and one API call per gene (plus a resolution call),
this will take a while and should run via SLURM, not interactively.
Includes a small delay between requests to be a reasonable API citizen.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import requests

GRAPHQL_URL = "https://api.platform.opentargets.org/api/v4/graphql"

SEARCH_QUERY = """
query SearchTarget($q: String!) {
  search(queryString: $q, entityNames: ["target"]) {
    hits {
      id
      entity
      name
    }
  }
}
"""

ASSOCIATIONS_QUERY = """
query TargetDiseases($ensemblId: String!) {
  target(ensemblId: $ensemblId) {
    id
    approvedSymbol
    associatedDiseases(page: {index: 0, size: 50}) {
      rows {
        disease {
          id
          name
        }
        score
      }
    }
  }
}
"""


def load_peptide_gene_symbols(gene_list_path):
    # Identical logic to pdc_proteomics_collector.py's function of the
    # same name, so both collectors derive the exact same gene set.
    data = json.load(open(gene_list_path))
    symbols = set()
    for rec in data:
        symbol = rec.get("gene_symbol")
        if symbol:
            symbols.add(symbol.upper())
        gene_names = rec.get("gene_names")
        if gene_names:
            for name in gene_names:
                if name:
                    symbols.add(name.upper())
    return symbols


def graphql_request(query, variables, retries=3):
    for attempt in range(retries):
        try:
            resp = requests.post(
                GRAPHQL_URL,
                json={"query": query, "variables": variables},
                timeout=30,
            )
            resp.raise_for_status()
            return resp.json()
        except requests.exceptions.RequestException as e:
            if attempt == retries - 1:
                print(f"  ERROR: {e}", file=sys.stderr)
                return None
            time.sleep(2 ** attempt)
    return None


def resolve_symbol_to_ensembl(symbol):
    result = graphql_request(SEARCH_QUERY, {"q": symbol})
    if not result or "data" not in result:
        return None
    hits = result["data"].get("search", {}).get("hits", [])
    for hit in hits:
        if hit.get("entity") == "target" and hit.get("name", "").upper() == symbol.upper():
            return hit["id"]
    for hit in hits:
        if hit.get("entity") == "target":
            return hit["id"]
    return None


def fetch_disease_associations(ensembl_id):
    result = graphql_request(ASSOCIATIONS_QUERY, {"ensemblId": ensembl_id})
    if not result or "data" not in result or not result["data"].get("target"):
        return []
    target = result["data"]["target"]
    gene_symbol = target.get("approvedSymbol")
    rows = target.get("associatedDiseases", {}).get("rows", [])
    return [
        {
            "gene": gene_symbol,
            "ensembl_id": ensembl_id,
            "disease_id": row["disease"]["id"],
            "disease_name": row["disease"]["name"],
            "association_score": row["score"],
            "data_type": "disease_association",
            "source": "OpenTargets",
        }
        for row in rows
        if row.get("disease")
    ]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gene-list", required=True, type=Path)
    ap.add_argument("--output", required=True, type=Path)
    ap.add_argument("--limit", type=int, default=None, help="Cap number of genes processed (for testing)")
    args = ap.parse_args()

    gene_symbols = sorted(load_peptide_gene_symbols(args.gene_list))
    print(f"Loaded {len(gene_symbols):,} peptide gene symbols")
    if args.limit:
        gene_symbols = gene_symbols[: args.limit]
        print(f"Limited to first {len(gene_symbols)} for this run")

    args.output.mkdir(parents=True, exist_ok=True)
    all_records = []
    resolved = 0
    unresolved = 0
    no_diseases = 0

    for i, symbol in enumerate(gene_symbols):
        ensembl_id = resolve_symbol_to_ensembl(symbol)
        if not ensembl_id:
            unresolved += 1
            continue
        resolved += 1

        records = fetch_disease_associations(ensembl_id)
        if not records:
            no_diseases += 1
        all_records.extend(records)

        if (i + 1) % 100 == 0:
            print(f"  Processed {i + 1}/{len(gene_symbols)} genes, {len(all_records):,} disease records so far")

        time.sleep(0.05)

    out_path = args.output / "opentargets_broad.json"
    with open(out_path, "w") as f:
        json.dump(all_records, f)

    print("\n=== SUMMARY ===")
    print(f"Genes resolved to Ensembl ID: {resolved:,}")
    print(f"Genes unresolved (skipped): {unresolved:,}")
    print(f"Resolved genes with zero disease associations: {no_diseases:,}")
    print(f"Total disease-association records: {len(all_records):,}")
    print(f"Output: {out_path}")


if __name__ == "__main__":
    main()

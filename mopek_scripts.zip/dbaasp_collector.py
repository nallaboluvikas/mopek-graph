"""
dbaasp_collector.py — collects DBAASP v4 peptide data via its real,
current, no-auth-required REST API (dbaasp.org/peptides), discovered
by directly inspecting the live OpenAPI spec at dbaasp.org/v3/api-docs
after the originally-documented (and deprecated) /api/v1 endpoint
returned 403 Forbidden.

Two phases:
  --phase list    Paginates GET /peptides (limit/offset) to collect
                   ALL ~25,542 peptides' basic records quickly (name,
                   sequence, complexity, monomers, pdb) — a handful of
                   large-page requests, not one per peptide.
  --phase detail  For each peptide ID from phase 1, fetches
                   GET /peptides/{id} for full detail: real UniProt
                   IDs (direct link to existing :Target nodes), real
                   PubMed IDs (direct link to existing :Publication
                   nodes), and quantitative targetActivities (species,
                   concentration, activity value). This is one request
                   per peptide (~25,542 calls) — slower, run in the
                   background. Saves incrementally so partial progress
                   is never lost if interrupted.

No API key or authentication required — confirmed via the OpenAPI
spec's components section (no securitySchemes declared) and via a
live, successful unauthenticated request.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import requests

BASE_URL = "https://dbaasp.org"


def fetch_list(output_dir: Path, page_size: int = 1000) -> list[dict]:
    all_peptides = []
    offset = 0
    while True:
        resp = requests.get(f"{BASE_URL}/peptides", params={"limit": page_size, "offset": offset}, timeout=60)
        resp.raise_for_status()
        data = resp.json()
        batch = data.get("data", [])
        total = data.get("totalCount", 0)
        all_peptides.extend(batch)
        print(f"  Fetched {len(all_peptides)}/{total} peptides")
        offset += page_size
        if offset >= total or not batch:
            break
        time.sleep(0.2)

    out_path = output_dir / "dbaasp_list.json"
    with open(out_path, "w") as f:
        json.dump(all_peptides, f)
    print(f"Phase 1 done. {len(all_peptides)} peptides written to {out_path}")
    return all_peptides


def fetch_detail(output_dir: Path, resume: bool = True) -> None:
    list_path = output_dir / "dbaasp_list.json"
    peptides = json.loads(list_path.read_text())
    ids = [p["id"] for p in peptides if p.get("id") is not None]

    out_path = output_dir / "dbaasp_detail.json"
    details = []
    done_ids = set()
    if resume and out_path.exists():
        details = json.loads(out_path.read_text())
        done_ids = {d["id"] for d in details if d.get("id") is not None}
        print(f"Resuming: {len(done_ids)} already collected")

    for i, pid in enumerate(ids):
        if pid in done_ids:
            continue
        try:
            resp = requests.get(f"{BASE_URL}/peptides/{pid}", timeout=30)
            resp.raise_for_status()
            details.append(resp.json())
        except requests.exceptions.RequestException as e:
            print(f"  ERROR fetching peptide {pid}: {e}")
        if (i + 1) % 200 == 0:
            with open(out_path, "w") as f:
                json.dump(details, f)
            print(f"  Detail progress: {len(details)}/{len(ids)} (saved checkpoint)")
        time.sleep(0.1)

    with open(out_path, "w") as f:
        json.dump(details, f)
    print(f"Phase 2 done. {len(details)} full peptide records written to {out_path}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase", required=True, choices=["list", "detail"])
    ap.add_argument("--output", required=True, type=Path)
    args = ap.parse_args()

    args.output.mkdir(parents=True, exist_ok=True)

    if args.phase == "list":
        fetch_list(args.output)
    else:
        fetch_detail(args.output)


if __name__ == "__main__":
    main()

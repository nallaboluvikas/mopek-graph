# MOPeK Source Scripts

This folder contains the collector and loader scripts used to build the
MOPeK knowledge graph described in the accompanying paper. These are
provided for **reproducibility and transparency**, not as a
point-and-click tool — running them requires re-collecting data
directly from each original public source (ChEMBL, UniProt, PharmGKB,
etc.), since we do not redistribute any source's raw data here (several
sources have their own attribution/redistribution terms, which this
avoids entirely by letting you pull fresh data from them yourself).

If you just want to **use** the finished graph rather than rebuild it,
you don't need anything in this folder — see the main repository README
for the ready-to-run Docker package instead.

## Structure

- **`base_loader.py`** — shared scaffolding class every loader builds
  on. Handles batching, MERGE-based idempotent writes (safe to re-run),
  and connection setup. Start here to understand the common pattern.
- **`*_collector.py`** — scripts that fetch raw data from a source's
  own bulk download or public API (e.g. `dbaasp_collector.py`,
  `dramp_collector_annotated.py`, `pubmed_collector_fixed.py`,
  `opentargets_collector_broad.py`). Not every source needed a custom
  collector — some loaders read a file downloaded by hand from the
  source's own website.
- **`*_loader.py`** — scripts that take collected/downloaded source
  data and load it into Neo4j, following the shared `BaseLoader`
  pattern (implementing `parse()` to map source fields onto the schema,
  and `load_batch()` for the actual Cypher writes).
- **`entity_resolution_*.py`** — the two entity-resolution passes
  (exact sequence match, RDKit InChIKey structural match) that create
  `SAME_AS` relationships across sources, described in Section 3.4 of
  the paper.
- **`merge_duplicate_targets.py`** — the one-time correction script for
  the duplicate-Target-node defect described in Section 4.3 / Table 4
  of the paper (kept here for transparency, not needed for a fresh run
  since the schema constraint that originally allowed the defect is
  now in place).

## Requirements

- Python 3.10+
- `neo4j` Python driver (`pip install neo4j`)
- `rdkit` (for the InChIKey entity resolution pass only —
  `pip install rdkit`)
- A running Neo4j instance (5.24.2 recommended, to match the schema
  constraints these scripts assume) with connection details passed via
  each script's `--uri`, `--user`, `--password` arguments

## General usage pattern

Each loader is run independently, pointed at a Neo4j instance and a
source data file:

```bash
python3 some_loader.py path/to/downloaded_data.json \
  --uri bolt://localhost:7687 --user neo4j --password your_password
```

Loaders use `MERGE`, not `CREATE`, so they are safe to re-run against
the same data without creating duplicates — useful if a run is
interrupted partway through.

## Schema

These scripts assume the Neo4j schema (node types, uniqueness
constraints, relationship types) described in Section 3.2 of the paper.
Several scripts will fail against an empty Neo4j instance until the
relevant constraints exist — see the paper's schema discussion for the
full list, since the constraint-creation statements themselves are not
included in this script set.

## A note on data sources

These scripts fetch from each source's own public API or bulk download
mechanism as it existed at the time this project was built (2026).
Source APIs and file formats do change over time; a script that worked
during this project's construction may need updating if a source has
since changed its endpoint structure, field names, or access
requirements (we encountered and fixed several such issues ourselves
during construction — see Table 4 in the paper for examples).

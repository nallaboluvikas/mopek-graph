"""
pharmgkb_variant_annotations_loader.py — loads PharmGKB variant
annotations into Neo4j as :PharmacogenomicAssociation nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/pharmgkb/variant_annotations.json
(65,486 total rows — but only 29,580 UNIQUE Variant Annotation IDs,
confirmed directly. Same mixed-schema pattern as
pharmgkb_summary_annotations_loader.py: the header row (with Gene,
Drug(s), Sentence, Phenotype, etc.) is followed by "Study Parameters"
rows for the same annotation (Study Type, sample sizes, allele
frequencies, p-values, confidence intervals — real statistical data,
identified by the presence of a "Study Parameters ID" field instead of
a Gene field).

Maps onto:
  (:PharmacogenomicAssociation {pgx_id, gene_symbol, variant_haplotypes,
                                drugs, pmid, phenotype_category,
                                significance, notes, sentence, alleles,
                                phenotype,
                                study_parameters: [json_string, ...],
                                source: "pharmgkb"})
  (:PharmacogenomicAssociation)-[:ASSOCIATED_WITH_GENE]->(:Gene)
    [MATCH on Gene.symbol]

study_parameters is a list of JSON-serialized study records (Neo4j
can't store a list of maps directly, per the lesson from
pharmgkb_pathways_loader.py).
"""

from __future__ import annotations

import argparse
import json as json_module
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class PharmGKBVariantAnnotationsLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        headers_by_id: dict[str, dict] = {}
        studies_by_id: dict[str, list] = {}

        for rec in self.read_json(raw_path):
            annotation_id = rec.get("Variant Annotation ID")
            if not annotation_id:
                continue

            if rec.get("Gene") and annotation_id not in headers_by_id:
                headers_by_id[annotation_id] = rec

            if rec.get("Study Parameters ID"):
                studies_by_id.setdefault(annotation_id, []).append(json_module.dumps({
                    "study_type": rec.get("Study Type"),
                    "study_cases": rec.get("Study Cases"),
                    "study_controls": rec.get("Study Controls"),
                    "characteristics": rec.get("Characteristics"),
                    "characteristics_type": rec.get("Characteristics Type"),
                    "frequency_in_cases": rec.get("Frequency In Cases"),
                    "frequency_in_controls": rec.get("Frequency In Controls"),
                    "p_value": rec.get("P Value"),
                    "ratio_stat_type": rec.get("Ratio Stat Type"),
                    "ratio_stat": rec.get("Ratio Stat"),
                    "confidence_interval_start": rec.get("Confidence Interval Start"),
                    "confidence_interval_stop": rec.get("Confidence Interval Stop"),
                    "biogeographical_groups": rec.get("Biogeographical Groups"),
                }))

        for annotation_id, rec in headers_by_id.items():
            yield {
                "pgx_id": f"pharmgkb:variant:{annotation_id}",
                "gene_symbol": rec.get("Gene"),
                "variant_haplotypes": rec.get("Variant/Haplotypes"),
                "drugs": rec.get("Drug(s)"),
                "pmid": rec.get("PMID"),
                "phenotype_category": rec.get("Phenotype Category"),
                "significance": rec.get("Significance"),
                "notes": rec.get("Notes"),
                "sentence": rec.get("Sentence"),
                "alleles": rec.get("Alleles"),
                "phenotype": rec.get("Phenotype"),
                "study_parameters": studies_by_id.get(annotation_id, []),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (pg:PharmacogenomicAssociation {pgx_id: row.pgx_id})
              ON CREATE SET
                pg.variant_haplotypes = row.variant_haplotypes,
                pg.drugs = row.drugs,
                pg.pmid = row.pmid,
                pg.phenotype_category = row.phenotype_category,
                pg.significance = row.significance,
                pg.notes = row.notes,
                pg.sentence = row.sentence,
                pg.alleles = row.alleles,
                pg.phenotype = row.phenotype,
                pg.study_parameters = row.study_parameters,
                pg.source = 'pharmgkb'
            WITH pg, row
            MATCH (g:Gene {symbol: row.gene_symbol})
            MERGE (pg)-[:ASSOCIATED_WITH_GENE]->(g)
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to pharmgkb/variant_annotations.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with PharmGKBVariantAnnotationsLoader(
        args.uri, args.user, args.password, "pharmgkb_variant_annotations"
    ) as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

"""
entity_resolution_inchikey.py — Step 4 entity resolution, SECOND pass:
structural identity matching via InChIKey, computed with RDKit from
SMILES where not already stored.

Complements entity_resolution_sequence_exact.py (the first pass),
which only covered ~87,824 of 158,043 Peptide nodes — everything with
a usable `sequence` property. This pass targets the remaining
peptides, which have SMILES instead (chiefly BindingDB's 70,219
records, none of which have sequence or inchi_key populated).

Why InChIKey and not raw SMILES string matching: the same molecule can
be validly written as different SMILES strings (different atom
ordering, stereochemistry notation, etc.) — an exact string match
would miss real duplicates. InChIKey is a canonical, order-independent
hash designed exactly to solve this; RDKit's Chem.MolFromSmiles +
Chem.MolToInchiKey gives a reliable structural identity key regardless
of how the original SMILES was written.

Process:
  1. Fetch all Peptide nodes with a non-empty `smiles` property.
  2. For nodes that already have a real inchi_key (ChEMBL: 21,965 of
     22,050), use it directly rather than recomputing.
  3. For nodes without one (BindingDB and any other SMILES-only
     source), compute InChIKey via RDKit. Invalid/unparseable SMILES
     are skipped and counted, not silently dropped without a trace.
  4. Group by InChIKey; create SAME_AS between different-source pairs,
     same conservative same-source-exclusion rule as the sequence
     pass.

Maps onto:
  (:Peptide)-[:SAME_AS {confidence: 0.95, method: "inchikey_structural"}]->(:Peptide)

Confidence is set slightly below the sequence-exact pass's 1.0 — while
InChIKey matching is a strong structural signal, it's one step removed
from an exact stored identifier (it depends on RDKit's SMILES
parsing/canonicalization being correct), so 0.95 reflects that it is
very high confidence but not quite as direct as matching an
already-authoritative field.

Given scale (up to ~92,000 SMILES to parse), this can take a while —
run via SLURM, not interactively.
"""

from __future__ import annotations

import argparse
import logging
from collections import defaultdict

from neo4j import GraphDatabase
from rdkit import Chem
from rdkit import RDLogger

# Silence RDKit's verbose stderr warnings for unparseable SMILES —
# we track and report failures ourselves via the skipped counter.
RDLogger.DisableLog("rdApp.*")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
log = logging.getLogger("entity_resolution_inchikey")

BATCH_SIZE = 2000


def fetch_all_peptides_with_smiles(session):
    result = session.run(
        """
        MATCH (p:Peptide)
        WHERE p.smiles IS NOT NULL AND p.smiles <> ''
        RETURN p.peptide_id AS peptide_id, p.smiles AS smiles,
               p.inchi_key AS inchi_key, p.source AS source
        """
    )
    return [
        (rec["peptide_id"], rec["smiles"], rec["inchi_key"], rec["source"])
        for rec in result
    ]


def compute_inchikey(smiles):
    try:
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            return None
        return Chem.MolToInchiKey(mol)
    except Exception:
        return None


def build_inchikey_groups(peptides):
    groups = defaultdict(list)
    skipped = 0
    reused_existing = 0
    computed = 0

    for peptide_id, smiles, existing_inchi_key, source in peptides:
        if existing_inchi_key:
            key = existing_inchi_key
            reused_existing += 1
        else:
            key = compute_inchikey(smiles)
            if key is None:
                skipped += 1
                continue
            computed += 1
        groups[key].append((peptide_id, source))

    log.info(
        "InChIKeys: %d reused from existing property, %d computed via RDKit, %d skipped (unparseable SMILES)",
        reused_existing, computed, skipped,
    )
    return groups


def build_same_as_pairs(groups):
    pairs = []
    for members in groups.values():
        if len(members) < 2:
            continue
        for i in range(len(members)):
            for j in range(i + 1, len(members)):
                id_a, source_a = members[i]
                id_b, source_b = members[j]
                if source_a != source_b:
                    pairs.append((id_a, id_b))
    return pairs


def write_same_as_batch(session, batch):
    session.run(
        """
        UNWIND $batch AS pair
        MATCH (a:Peptide {peptide_id: pair[0]})
        MATCH (b:Peptide {peptide_id: pair[1]})
        MERGE (a)-[r:SAME_AS]->(b)
          SET r.confidence = 0.95,
              r.method = 'inchikey_structural'
        """,
        batch=[[a, b] for a, b in batch],
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    driver = GraphDatabase.driver(args.uri, auth=(args.user, args.password))
    try:
        with driver.session() as session:
            log.info("Fetching all Peptide nodes with a non-empty smiles...")
            peptides = fetch_all_peptides_with_smiles(session)
            log.info("Fetched %d peptides with SMILES", len(peptides))

            groups = build_inchikey_groups(peptides)
            pairs = build_same_as_pairs(groups)
            log.info("Found %d cross-source InChIKey-match pairs", len(pairs))

            if args.dry_run:
                for p in pairs[:20]:
                    log.info("  %s", p)
                log.info("Dry run — no relationships created.")
                return

            for i in range(0, len(pairs), BATCH_SIZE):
                batch = pairs[i : i + BATCH_SIZE]
                write_same_as_batch(session, batch)
                log.info("Wrote %d/%d SAME_AS relationships", min(i + BATCH_SIZE, len(pairs)), len(pairs))

            log.info("Done. %d SAME_AS relationships created/verified.", len(pairs))
    finally:
        driver.close()


if __name__ == "__main__":
    main()

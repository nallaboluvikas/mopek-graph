"""
tumorhope2_loader.py — loads TumorHoPe2 (tumor-homing peptides) into
Neo4j as :Peptide nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/tumorhope2/tumorhope2_all.json
(1,881 records — confirmed to be the exact merge of tumorhope2_modified.json
(595) + tumorhope2_natural.json (1,286) = 1,881. Only this merged file
is loaded. All 1,881 headers are unique — confirmed directly — so no
multi-category aggregation is needed here, unlike satpdb_loader.py.

Maps onto:
  (:Peptide {peptide_id, header, sequence, modification_category, source: "tumorhope2"})
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class TumorHoPe2Loader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            header = rec.get("header")
            if not header:
                continue

            yield {
                "peptide_id": f"tumorhope2:{header}",
                "header": header,
                "sequence": rec.get("sequence"),
                "modification_category": rec.get("modification_category"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (p:Peptide {peptide_id: row.peptide_id})
              ON CREATE SET
                p.header = row.header,
                p.sequence = row.sequence,
                p.modification_category = row.modification_category,
                p.source = 'tumorhope2'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to tumorhope2/tumorhope2_all.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with TumorHoPe2Loader(args.uri, args.user, args.password, "tumorhope2") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

"""
satpdb_structures_loader.py — loads SATPdb structure metadata into
Neo4j as :Structure nodes, WITH real HAS_STRUCTURE links back to
SATPdb :Peptide nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/satpdb_structures/structure_index.json
(17,284 records — metadata index; the actual .pdb coordinate files
inside satpdb_structures17284.tgz are not needed for graph loading).

Maps onto:
  (:Structure {structure_id, filename, format, size_bytes, source: "satpdb"})
  (:Peptide {peptide_id: "satpdb:" + peptide_id})-[:HAS_STRUCTURE]->(:Structure)

Unlike the earlier pdb_loader.py (which explicitly could NOT create
HAS_STRUCTURE links, since generic PDB search results have no peptide
identifier), SATPdb's structure_index.json peptide_id field
(e.g. "satpdb10001") directly matches the peptide_id format used by
satpdb_loader.py ("satpdb:" + header) — so a real MATCH is possible
here. Uses MATCH (not MERGE) for the Peptide side, since these
peptides should already exist from satpdb_loader.py; unmatched
records are silently-safe (Cypher MATCH just skips), but their count
should be checked via a direct Cypher query after loading, not just
the loader's log line (lesson learned from tonight's ChEMBL bioactivity
bug).
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class SATPdbStructuresLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            peptide_id = rec.get("peptide_id")
            if not peptide_id:
                continue  # skip records with no usable identifier

            yield {
                "structure_id": f"satpdb:{peptide_id}",
                "peptide_id": f"satpdb:{peptide_id}",
                "filename": rec.get("filename"),
                "format": rec.get("format"),
                "size_bytes": rec.get("size_bytes"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (s:Structure {structure_id: row.structure_id})
              ON CREATE SET
                s.filename = row.filename,
                s.format = row.format,
                s.size_bytes = row.size_bytes,
                s.source = 'satpdb'
            WITH s, row
            MATCH (p:Peptide {peptide_id: row.peptide_id})
            MERGE (p)-[:HAS_STRUCTURE]->(s)
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to satpdb_structures/structure_index.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with SATPdbStructuresLoader(args.uri, args.user, args.password, "satpdb_structures") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

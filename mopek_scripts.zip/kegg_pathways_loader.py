"""
kegg_pathways_loader.py — loads KEGG pathway records into Neo4j as
:Pathway nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/pathways/pathways.json
(257 records).

NOTE: every record's `genes` and `compounds` arrays are empty
(confirmed directly: 0/257 non-empty for both) — so no gene/compound
linkage is possible from this data. These load as standalone Pathway
nodes only, same category of gap as PDB/PubMed's missing peptide
linkage earlier this session.

Maps onto:
  (:Pathway {pathway_id, name, pathway_class, url, source: "kegg"})

Note: this reuses the :Pathway node type and pathway_id constraint
already established by pharmgkb_pathways_loader.py — KEGG's own
pathway_id format (e.g. "map04080") is naturally distinct from
PharmGKB's PA-number-based IDs, so no collision risk.
NOTE (2026-09-22, post-load fix): pathways.json is NOT pure KEGG data —
it's a MIX of KEGG and Reactome records (confirmed directly: 237 of
257 records have their own "source": "Reactome" field embedded in the
record itself). The first version of this loader blindly labeled every
record source='kegg', which incorrectly overwrote the true origin for
197 records that also exist in reactome/reactions.json (confirmed via
Cypher: 197 Pathway nodes had an R-HSA-style pathway_id but
source='kegg' instead of 'reactome', because this loader ran first,
created them with ON CREATE SET, and reactome_loader.py's later MERGE
correctly found them already existing and left the wrong source label
in place, per ON CREATE SET semantics).

Fixed by filtering to only records whose own `source` field is
literally "KEGG" before loading — the Reactome-sourced records in this
same file are intentionally skipped here, since they're redundant with
(and less complete than) reactome/reactions.json's own entries.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class KEGGPathwaysLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            if rec.get("source") != "KEGG":
                continue  # skip the Reactome-sourced records mixed into this file

            pathway_id = rec.get("pathway_id")
            if not pathway_id:
                continue

            yield {
                "pathway_id": pathway_id,
                "name": rec.get("name"),
                "pathway_class": rec.get("pathway_class"),
                "url": rec.get("url"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (pw:Pathway {pathway_id: row.pathway_id})
              ON CREATE SET
                pw.name = row.name,
                pw.pathway_class = row.pathway_class,
                pw.url = row.url,
                pw.source = 'kegg'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to pathways/pathways.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with KEGGPathwaysLoader(args.uri, args.user, args.password, "kegg") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

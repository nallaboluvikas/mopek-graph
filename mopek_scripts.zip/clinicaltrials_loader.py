"""
clinicaltrials_loader.py — loads ClinicalTrials.gov trial data into
Neo4j as :ClinicalTrial nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/clinicaltrials/trials.json
(34,667 records — confirmed via streaming count, matches the project's
Notion documentation exactly).

Uses ijson to stream records rather than BaseLoader.read_json(), same
reasoning as gwas_bulk_loader.py: this file (47MB) killed a plain
json.load() attempt on the login node's tight interactive memory cap,
so streaming is used defensively even though this file is much smaller
than the 412MB GWAS file — better to always stream for any file that's
shown OOM risk, rather than assume "small enough."

Maps onto:
  (:ClinicalTrial {nct_id, title, official_title, status, phase,
                    study_type, start_date, completion_date,
                    enrollment, conditions, sponsor, summary,
                    primary_outcomes, url, source: "clinicaltrials"})
  (:ClinicalTrial)-[:TESTED_INTERVENTION]->(:Drug)
    [MATCH on Drug.name — best-effort name matching against the
     `interventions` list; ClinicalTrials.gov intervention names are
     free text (drug names, placebo, procedures, devices, etc.), not
     IDs, so this will only catch interventions whose name happens to
     match a Drug.name exactly. Placebo/device/procedure entries will
     simply not match anything, which is correct behavior, not a bug.
     A more thorough match would need fuzzy/synonym matching — left as
     a follow-up entity-resolution task like other cross-source gaps
     this session.]
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

import ijson

from base_loader import BaseLoader


class ClinicalTrialsLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        with open(raw_path, "rb") as f:
            for rec in ijson.items(f, "item"):
                nct_id = rec.get("nct_id")
                if not nct_id:
                    continue

                phase = rec.get("phase") or []
                interventions = rec.get("interventions") or []
                conditions = rec.get("conditions") or []
                primary_outcomes = rec.get("primary_outcomes") or []

                yield {
                    "nct_id": nct_id,
                    "title": rec.get("title"),
                    "official_title": rec.get("official_title"),
                    "status": rec.get("status"),
                    "phase": [p for p in phase if p is not None],
                    "study_type": rec.get("study_type"),
                    "start_date": rec.get("start_date"),
                    "completion_date": rec.get("completion_date"),
                    "enrollment": rec.get("enrollment"),
                    "conditions": [c for c in conditions if c is not None],
                    "sponsor": rec.get("sponsor"),
                    "summary": rec.get("summary"),
                    "primary_outcomes": [o for o in primary_outcomes if o is not None],
                    "url": rec.get("url"),
                    "interventions": [i for i in interventions if i is not None],
                }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (ct:ClinicalTrial {nct_id: row.nct_id})
              ON CREATE SET
                ct.title = row.title,
                ct.official_title = row.official_title,
                ct.status = row.status,
                ct.phase = row.phase,
                ct.study_type = row.study_type,
                ct.start_date = row.start_date,
                ct.completion_date = row.completion_date,
                ct.enrollment = row.enrollment,
                ct.conditions = row.conditions,
                ct.sponsor = row.sponsor,
                ct.summary = row.summary,
                ct.primary_outcomes = row.primary_outcomes,
                ct.url = row.url,
                ct.source = 'clinicaltrials'
            WITH ct, row
            UNWIND row.interventions AS intervention_name
            MATCH (d:Drug {name: intervention_name})
            MERGE (ct)-[:TESTED_INTERVENTION]->(d)
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to clinicaltrials/trials.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with ClinicalTrialsLoader(args.uri, args.user, args.password, "clinicaltrials") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

"""
string_loader.py — loads STRING protein-protein interactions into Neo4j.

Reads the raw data/string/interactions.json directly (this source was
never run through the normalization pipeline — no normalized file
exists yet, unlike chembl/uniprot/pdb/pubmed).

Maps onto:
  (:Target)-[:INTERACTS_WITH {score, experimental, coexpression,
                              database, textmining, source: "string"}]
           ->(:Target)

Note (2026-08-18): only 1 of the 20 genes in this STRING dataset
(OPRM1) already existed as a :Target node from UniProt — the current
UniProt load (1,080 records) isn't a comprehensive proteome, so it
doesn't cover most of these hormone-receptor genes. This loader uses
MERGE (not MATCH) on gene_symbol, so it creates lightweight stub
:Target nodes for the other 19 genes rather than silently dropping
their interactions. These stubs only have gene_symbol + source for
now; they can be enriched later if/when a broader UniProt pull
covers them. Note stub nodes here are keyed on gene_symbol, not
uniprot_id, so reconciling them with fuller UniProt nodes later isn't
automatic — flagging for the Step 4 entity-resolution pass.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class StringLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            gene_a = rec.get("protein_a")
            gene_b = rec.get("protein_b")
            if not gene_a or not gene_b:
                continue  # skip incomplete records

            yield {
                "gene_a": gene_a,
                "gene_b": gene_b,
                "string_id_a": rec.get("string_id_a"),
                "string_id_b": rec.get("string_id_b"),
                "score": rec.get("score"),
                "experimental": rec.get("experimental"),
                "coexpression": rec.get("coexpression"),
                "database": rec.get("database"),
                "textmining": rec.get("textmining"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (a:Target {gene_symbol: row.gene_a})
              ON CREATE SET a.source = 'string', a.string_id = row.string_id_a
            MERGE (b:Target {gene_symbol: row.gene_b})
              ON CREATE SET b.source = 'string', b.string_id = row.string_id_b
            MERGE (a)-[r:INTERACTS_WITH]->(b)
              SET r.score = row.score,
                  r.experimental = row.experimental,
                  r.coexpression = row.coexpression,
                  r.database = row.database,
                  r.textmining = row.textmining,
                  r.source = 'string'
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to data/string/interactions.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with StringLoader(args.uri, args.user, args.password, "string") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

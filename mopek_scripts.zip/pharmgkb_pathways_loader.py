"""
pharmgkb_pathways_loader.py — loads PharmGKB pathway reaction data into
Neo4j as :Pathway nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/pharmgkb/pathways.json
(3,178 records — but only 271 UNIQUE pathways, confirmed directly. Each
record is actually one REACTION STEP within a named pathway (grouped
by the `_source_file` field, e.g.
"PA166163705-Diclofenac_Pathway_Pharmacokinetics.tsv" has 16 steps).

Same lesson as satpdb_loader.py/thpdb_loader.py: aggregate all rows
sharing a pathway identity in Python BEFORE loading, storing the
individual reaction steps as a list property (`reactions`) rather than
creating 3,178 disconnected single-step nodes.

pathway_id is derived from the PA-number prefix of _source_file (e.g.
"PA166163705"), matching the schema's existing pathway_id constraint.
name is derived from the rest of the filename, cleaned up for
readability.

NOTE (2026-08-19, post-load fix): Neo4j properties can only be
primitive types or ARRAYS OF PRIMITIVES — not a list of maps/objects.
The first version of this loader tried to store `reactions` as a list
of dicts directly and Neo4j rejected it (CypherTypeError). Each
reaction step is now serialized to a JSON string via json.dumps()
before storage; parse with json.loads() when reading `reactions` back
out in a query.

Maps onto:
  (:Pathway {pathway_id, name,
             reactions: [json_string, json_string, ...],
             source: "pharmgkb"})
  (:Gene)-[:CONTROLS_REACTION]->(:Pathway)
    [MATCH on Gene.symbol, only where a reaction step's Control Type
     is "Gene" — same MATCH-not-MERGE reasoning as
     pharmgkb_clinical_variants_loader.py: a missing match here more
     likely reflects a symbol/naming mismatch than a genuinely new gene]
"""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


def _parse_source_file(source_file: str) -> tuple[str, str]:
    # e.g. "PA166163705-Diclofenac_Pathway_Pharmacokinetics.tsv"
    #   -> pathway_id="PA166163705", name="Diclofenac Pathway Pharmacokinetics"
    stem = source_file.rsplit(".", 1)[0]
    pathway_id, _, rest = stem.partition("-")
    name = rest.replace("_", " ").strip()
    return pathway_id, name


class PharmGKBPathwaysLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        by_pathway: dict[str, dict] = {}
        reactions_by_pathway: dict[str, list] = defaultdict(list)
        gene_controllers_by_pathway: dict[str, set] = defaultdict(set)

        for rec in self.read_json(raw_path):
            source_file = rec.get("_source_file")
            if not source_file:
                continue

            pathway_id, name = _parse_source_file(source_file)
            if pathway_id not in by_pathway:
                by_pathway[pathway_id] = {"pathway_id": pathway_id, "name": name}

            reactions_by_pathway[pathway_id].append(json.dumps({
                "from_entity": rec.get("From"),
                "to_entity": rec.get("To"),
                "reaction_type": rec.get("Reaction Type"),
                "controller": rec.get("Controller"),
                "control_type": rec.get("Control Type"),
                "cell_type": rec.get("Cell Type"),
                "pmids": rec.get("PMIDs"),
                "summary": rec.get("Summary"),
            }))

            if rec.get("Control Type") == "Gene" and rec.get("Controller"):
                gene_controllers_by_pathway[pathway_id].add(rec["Controller"])

        for pathway_id, base in by_pathway.items():
            yield {
                "pathway_id": pathway_id,
                "name": base["name"],
                "reactions": reactions_by_pathway[pathway_id],
                "gene_controllers": sorted(gene_controllers_by_pathway[pathway_id]),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (pw:Pathway {pathway_id: row.pathway_id})
              ON CREATE SET
                pw.name = row.name,
                pw.reactions = row.reactions,
                pw.source = 'pharmgkb'
            WITH pw, row
            UNWIND row.gene_controllers AS gene_symbol
            MATCH (g:Gene {symbol: gene_symbol})
            MERGE (g)-[:CONTROLS_REACTION]->(pw)
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to pharmgkb/pathways.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with PharmGKBPathwaysLoader(args.uri, args.user, args.password, "pharmgkb_pathways") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

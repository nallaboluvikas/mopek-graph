"""
ncbi_gene_loader.py — loads NCBI Gene records into Neo4j as :Gene
nodes, and separately enriches matching Gene nodes with Ensembl data.

Handles two files:
  --mode genes    data/genomics/genes.json (78 records) — real
                  NCBI Gene data with gene_id matching the schema's
                  ncbi_gene_id constraint directly. MERGEs onto the
                  SAME Gene nodes already created by
                  pharmgkb_genes_loader.py where ncbi_gene_id matches,
                  enriching them with `summary`/`location` fields
                  PharmGKB's own gene export didn't have.
  --mode ensembl  data/genomics/ensembl.json (5 records) — tiny
                  Ensembl gene metadata, matched by gene SYMBOL
                  instead (no ncbi_gene_id in this file), enriching
                  existing Gene nodes with ensembl_id/biotype/strand.

Maps onto:
  (:Gene {ncbi_gene_id, full_name, chromosome, location, summary})
    [mode=genes; MERGE on ncbi_gene_id]
  (:Gene {ensembl_id, biotype, strand, ensembl_description})
    [mode=ensembl; MATCH on symbol, SET enrichment properties]
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class NCBIGeneLoader(BaseLoader):
    def __init__(self, uri, user, password, source_name, mode: str):
        super().__init__(uri, user, password, source_name)
        self.mode = mode

    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            if self.mode == "genes":
                gene_id = rec.get("gene_id")
                if not gene_id:
                    continue
                yield {
                    "ncbi_gene_id": gene_id,
                    "gene_symbol": rec.get("gene_symbol"),
                    "full_name": rec.get("full_name"),
                    "chromosome": rec.get("chromosome"),
                    "location": rec.get("location"),
                    "summary": rec.get("summary"),
                }
            else:  # ensembl
                gene_symbol = rec.get("gene_symbol")
                if not gene_symbol:
                    continue
                yield {
                    "gene_symbol": gene_symbol,
                    "ensembl_id": rec.get("ensembl_id"),
                    "biotype": rec.get("biotype"),
                    "strand": rec.get("strand"),
                    "ensembl_description": rec.get("description"),
                }

    def load_batch(self, tx, batch: list[dict]) -> None:
        if self.mode == "genes":
            tx.run(
                """
                UNWIND $batch AS row
                MERGE (g:Gene {ncbi_gene_id: row.ncbi_gene_id})
                  ON CREATE SET
                    g.symbol = row.gene_symbol,
                    g.source = 'ncbi_gene'
                SET
                  g.full_name = row.full_name,
                  g.chromosome = row.chromosome,
                  g.location = row.location,
                  g.summary = row.summary
                """,
                batch=batch,
            )
        else:
            tx.run(
                """
                UNWIND $batch AS row
                MATCH (g:Gene {symbol: row.gene_symbol})
                SET
                  g.ensembl_id = row.ensembl_id,
                  g.biotype = row.biotype,
                  g.strand = row.strand,
                  g.ensembl_description = row.ensembl_description
                """,
                batch=batch,
            )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path)
    ap.add_argument("--mode", required=True, choices=["genes", "ensembl"])
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with NCBIGeneLoader(args.uri, args.user, args.password, "ncbi_gene", args.mode) as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()

"""
alphafold_loader.py — loads AlphaFold predicted structures into Neo4j
as :Structure nodes, with real HAS_STRUCTURE links to :Target nodes.

Reads /projects/pbpk/vikas/pepzen/data_collection/data/alphafold/predictions.json
(994 records).

Maps onto:
  (:Structure {structure_id, entry_id, model_created, latest_version,
               plddt_global, pdb_url, cif_url, pae_image_url,
               source: "alphafold"})
  (:Target {uniprot_id})-[:HAS_STRUCTURE]->(:Structure)

Uses MATCH (not MERGE) for the Target side, since these should already
exist from uniprot_loader_v2.py — if a uniprot_id here isn't already a
Target node, that record's structure link is skipped (verify actual
count via Cypher after loading, per this session's now-standard
practice, not just the loader's log).

Note: HAS_STRUCTURE here goes (:Target)->(:Structure), not
(:Peptide)->(:Structure) like satpdb_structures_loader.py — AlphaFold
predicts protein/target structures, not peptide-drug structures, so
the relationship direction correctly reflects what's actually being
modeled.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterator

from base_loader import BaseLoader


class AlphaFoldLoader(BaseLoader):
    def parse(self, raw_path: Path) -> Iterator[dict]:
        for rec in self.read_json(raw_path):
            entry_id = rec.get("entry_id")
            uniprot_id = rec.get("uniprot_id")
            if not entry_id or not uniprot_id:
                continue

            yield {
                "structure_id": f"alphafold:{entry_id}",
                "entry_id": entry_id,
                "uniprot_id": uniprot_id,
                "model_created": rec.get("model_created"),
                "latest_version": rec.get("latest_version"),
                "plddt_global": rec.get("plddt_global"),
                "pdb_url": rec.get("pdb_url"),
                "cif_url": rec.get("cif_url"),
                "pae_image_url": rec.get("pae_image_url"),
            }

    def load_batch(self, tx, batch: list[dict]) -> None:
        tx.run(
            """
            UNWIND $batch AS row
            MERGE (s:Structure {structure_id: row.structure_id})
              ON CREATE SET
                s.entry_id = row.entry_id,
                s.model_created = row.model_created,
                s.latest_version = row.latest_version,
                s.plddt_global = row.plddt_global,
                s.pdb_url = row.pdb_url,
                s.cif_url = row.cif_url,
                s.pae_image_url = row.pae_image_url,
                s.source = 'alphafold'
            WITH s, row
            MATCH (t:Target {uniprot_id: row.uniprot_id})
            MERGE (t)-[:HAS_STRUCTURE]->(s)
            """,
            batch=batch,
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_path", type=Path, help="Path to alphafold/predictions.json")
    ap.add_argument("--uri", default="bolt://localhost:7687")
    ap.add_argument("--user", default="neo4j")
    ap.add_argument("--password", required=True)
    args = ap.parse_args()

    with AlphaFoldLoader(args.uri, args.user, args.password, "alphafold") as loader:
        loader.run(args.raw_path)


if __name__ == "__main__":
    main()
